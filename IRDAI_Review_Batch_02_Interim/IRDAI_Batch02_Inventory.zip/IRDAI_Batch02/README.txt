IRDAI Review Batch 02
This additional review batch contains 625 source records and 641 unchanged original PDFs.
The 163 records already supplied in Batch 01 are not repeated as inventory records.
Open IRDAI_Inventory_Batch_02.xlsx. The title opens the first local PDF. Website name opens the official source.
Audit/PDF_Manifest.csv maps every source record to all its original attachments and SHA-256 values.
Multiple source records can share identical PDF bytes. Source-record counts are not unique-law counts.
The seven inventory fields are document title, original document date, issuer, nature, website, preliminary AEBC assessment and addressee.
The date is not a webpage upload date or an assumed effective date. Date role and printed date are in the PDF manifest.
Applicability is a preliminary document-based assessment. It is not Legal/Compliance approval or a certification of current force.
These records passed the supplied literal source-scope screen and had no recorded metadata/date/component/identity hold at assembly.
This is not the complete IRDAI inventory. Other captured records remain under review and are not represented as cleared here.
Keep the workbook, Audit folder and Originals folder together so relative file links work after transfer.
Do not upload or send internal workbooks to any additional destination beyond the transfer route authorised for this project.
