AMEX READY FAQ / MAILBOX PACKAGE - 2026-07-20

This package fixes the Windows path-too-long extraction issue.

Use this folder after extracting the GitHub zip:

  FAQ_MAILBOX_AMEX_READY_20260720

Open this workbook first:

  RBI_KMT_FAQ_Mailbox_Inventory_AMEX_READY_20260720.xlsx

PDF folders:

  01_KMT_FAQ_PDFs              54 PDFs
  02_KMT_MAILBOX_PDFs          309 PDFs
  03_RBI_FAQ_PDFs              51 PDFs

Important:

- Raw HTML/text evidence folders are intentionally not included in this AMEX-ready transfer.
- QA preview PNG files are intentionally not included.
- All PDF filenames are short, for example KF001.pdf, KM001.pdf, RF001.pdf.
- AMEX_READY_FILE_INDEX.csv maps each short PDF name back to source, title, URL, category and mapping status.
- The source-copy workbook from the earlier package is retained as a backup file.
