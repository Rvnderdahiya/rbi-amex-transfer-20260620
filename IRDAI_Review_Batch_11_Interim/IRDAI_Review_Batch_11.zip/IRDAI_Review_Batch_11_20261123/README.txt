IRDAI Review Batch 11Duplicate control: two additional reviewed source IDs are not introduced as new rows here. Source 817697 is already represented by the UAPA Nodal Officer notice in Batch 10, and source 818166 matches the Controlled Fund clarification already in Batch 02. Their original versions and review evidence remain preserved for consolidation. Sources 817710 and 817723 are combined as one MFL licence-cancellation notice in this batch, with both source occurrences and all PDF versions preserved in the manifest.
19 inventory entries from 20 additional source records. Interim reviewed subset; not the complete regulator handover.
25 unchanged original PDFs are included.
The workbook contains only the seven requested fields. Title opens a supplied original; Website name opens the official source.
Audit/PDF_Manifest.csv maps every source occurrence, component PDF, own issue date, notice pages and source URL.
Audit/All_Source_Reviews.csv accounts for all 30 source records reviewed for this batch, including exclusions and unresolved holds. Files for unreleased sources remain in the collection audit and are not claimed delivered in this subset.
Issue dates come from the reviewed document, not from portal upload, publication, effective or historical citation dates. Ambiguous dates are held.
Multiple notifications in one Gazette PDF have separate rows; Hindi and English versions of the same instrument are not separate regulations.
Representation duplicates are merged only with shared original bytes or identical complete-page images and matching own reference, title, issuer and date; all original versions and source occurrences are preserved.
A title in an older catalogue is not treated as overriding the actual original. Unreconciled identity and missing substantive components remain under review.
Not expressly stated means no express addressee was found; operative subjects are labelled separately and are not represented as a printed To line.
Applicability is a preliminary document-specific assessment. Conditional exposure, historical authorisation and current force require Compliance/Legal confirmation; no final legal approval is asserted.
Retained under collection rules does not mean active, currently binding or applicable to AEBC. No RBI/KMT Tranche 1 active-only/title/addressee filter was imported.
Extract to a short folder and keep the workbook, Originals and Audit folders together. No screenshots or substitute generated PDFs are included.
