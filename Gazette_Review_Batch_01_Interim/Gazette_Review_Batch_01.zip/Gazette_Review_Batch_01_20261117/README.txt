Gazette of India Review Batch 01
This interim batch contains 41 fully reviewed single-notice source records and their unchanged downloaded Gazette PDFs.
This is not the complete Gazette inventory or full Tranche 2 handover.
The Inventory worksheet has the seven requested fields. Title opens the local PDF; Website name opens its official Gazette URL.
Audit/PDF_Manifest.csv maps every entry to the source record, original file, SHA-256, reference, issue date and Gazette publication date.
The Date column records the notification issue date from the reviewed original. Publication, portal-upload and effective dates are not silently substituted.
AEBC applicability is a preliminary document-specific assessment, not Legal/Compliance sign-off or certification that historical instruments remain in force.
Some Finance notices concern tax or customs topics but were retained because the agreed exclusion applies only to the published Office field or an Office heading. Subject matter or an enacting-authority reference alone was not treated as an excluded Office.
The MHA notices passed the department-first rule and then the supplied inclusion-keyword checks. A UAPA tribunal constitution is distinguished from an operative bank direction or a final tribunal determination.
Other source records, multi-instrument bundles and unresolved originals are not represented as completed by this batch.
Extract the ZIP to a short folder and keep the workbook, Originals and Audit folders together.
