IRDAI Consolidated Review Inventory

904 rows. This replaces manual joining of the referenced interim batches, not the remaining unreviewed source universe. Do not add these rows to the old batch totals.
Only the seven requested fields appear in the workbook. Title opens its primary local original; Website opens the official source. Every supplied component/version is mapped in Audit/PDF_Manifest.csv.
Confirmed repeat entries are mapped once, while all original files and source occurrences remain preserved. Known metadata corrections are applied and logged.
Review-required UIDAI versions are expressly flagged in Applicability and Nature; missing/clipped content and language discrepancies are not repaired or treated as cleared.
Dates retain the original source-review qualifications. Issue, publication, compilation, effective and cited dates are different roles; unknown days are not invented.
This is a consolidated reviewed subset, not a complete regulator inventory, certified unique-law count, current-force determination or final AEBC legal applicability approval.
Keep the workbook, Originals and Audit folders together and extract to a short folder. No screenshot substitutes are supplied.
