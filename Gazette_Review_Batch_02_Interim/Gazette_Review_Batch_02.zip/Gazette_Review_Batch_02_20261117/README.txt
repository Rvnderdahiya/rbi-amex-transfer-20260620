Gazette of India Review Batch 02
33 individually reviewed notifications are represented by 33 inventory rows from 9 original Gazette PDFs.
This is an additional interim subset, not the full Gazette or Tranche 2 handover.
The originals are unchanged complete publications. They may contain other ministries or notices excluded from this inventory.
Do not count the Hindi and English versions as separate regulations. Do not count one PDF as necessarily one notification.
Title begins with the notice reference and opens the local original. Website name opens the official original URL.
Audit/PDF_Manifest.csv gives the original pages, issue date, source record and SHA-256 for every inventory row.
Audit/Notice_Scope_and_Holds.csv accounts for all 68 observed notices in these 9 originals: 33 released, 5 retained notices held for their own issue dates, and 30 outside scope or excluded by the individual source rules.
The five unresolved issue dates are not filled using neighbouring notices, effective dates or the Gazette publication date.
A rescission of a prior provisional-duty notification is distinguished from withdrawal of a companion definitive-duty notification.
Finance Office exclusions apply only to the agreed published field/heading, not to tax topic words or a government appointee posting.
AEBC assessment is preliminary and document-specific. Conditional business roles and historical current-force questions are not certified as final Legal/Compliance decisions.
Extract the ZIP to a short folder and keep the workbook, Originals and Audit folders together.
