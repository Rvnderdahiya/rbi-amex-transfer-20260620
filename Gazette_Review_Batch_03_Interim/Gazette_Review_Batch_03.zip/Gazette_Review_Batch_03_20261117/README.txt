Gazette Review Batch 03
85 inventory entries from 80 additional source records. Interim reviewed subset; not the complete regulator handover.
80 unchanged original PDFs are included.
The workbook contains only the seven requested fields. Title opens a supplied original; Website name opens the official source.
Audit/PDF_Manifest.csv maps every source occurrence, component PDF, own issue date, notice pages and source URL.
Audit/All_Source_Reviews.csv accounts for all 90 source records reviewed for this batch, including exclusions and unresolved holds. Files for unreleased sources remain in the collection audit and are not claimed delivered in this subset.
Issue dates come from the reviewed document, not from portal upload, publication, effective or historical citation dates. Ambiguous dates are held.
Multiple notifications in one Gazette PDF have separate rows; Hindi and English versions of the same instrument are not separate regulations.
Representation duplicates are merged only with shared original bytes or identical complete-page images and matching own reference, title, issuer and date; all original versions and source occurrences are preserved.
A title in an older catalogue is not treated as overriding the actual original. Unreconciled identity and missing substantive components remain under review.
Not expressly stated means no express addressee was found; operative subjects are labelled separately and are not represented as a printed To line.
Applicability is a preliminary document-specific assessment. Conditional exposure, historical authorisation and current force require Compliance/Legal confirmation; no final legal approval is asserted.
Retained under collection rules does not mean active, currently binding or applicable to AEBC. No RBI/KMT Tranche 1 active-only/title/addressee filter was imported.
Extract to a short folder and keep the workbook, Originals and Audit folders together. No screenshots or substitute generated PDFs are included.
