IRDAI Review Batch 04
This additional review batch contains 13 source records and 17 unchanged original PDFs.
The 798 records already supplied in previous batches are not repeated as inventory records.
Open IRDAI_Inventory_Batch_04.xlsx. The title opens the first local PDF. Website name opens the official source.
Audit/PDF_Manifest.csv maps every source record to all its original attachments and SHA-256 values.
Multiple source records can share identical PDF bytes. Source-record counts are not unique-law counts.
The seven inventory fields are document title, original document date, issuer, nature, website, preliminary AEBC assessment and addressee.
The date is not a webpage upload date or an assumed effective date. Date role and printed date are in the PDF manifest.
Applicability is a preliminary document-based assessment. It is not Legal/Compliance approval or a certification of current force.
These records passed the supplied literal source-scope screen and had no recorded metadata/date/component/identity hold at assembly.
This is not the complete IRDAI inventory. Other captured records remain under review and are not represented as cleared here.
Keep the workbook, Audit folder and Originals folder together so relative file links work after transfer.
Do not upload or send internal workbooks to any additional destination beyond the transfer route authorised for this project.

There are 9 inventory entries representing 13 source records after four confirmed catalogue-duplicate merges. All source occurrences and original PDFs are preserved. Consultation notices for the August and September 2006 broker-committee meetings are different notices, not one merged meeting. Their underlying 19 July 2006 committee order and Terms of Reference were previously supplied in Batch 01 under source 697879. Neither notice is represented as amended broker regulations.
