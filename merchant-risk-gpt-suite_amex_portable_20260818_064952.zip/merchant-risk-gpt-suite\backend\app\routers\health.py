from fastapi import APIRouter


router = APIRouter(tags=["health"])


@router.get("/health")
def health_check() -> dict[str, str]:
    return {
        "status": "ok",
        "service": "merchant-risk-gpt-suite",
        "policy": "storage-and-analysis-only-no-crawling",
    }
