# Architecture

## Components

- Merchant Risk Discovery GPT: conducts GPT-led public discovery using ChatGPT web search/browsing only.
- AmEx Acceptance & Linkage GPT: conducts GPT-led passive acceptance evidence review and linkage pack creation.
- FastAPI backend: stores runs, candidates, signals, evidence, reviews, linkage packs, reports, and exports.
- SQLite local database: development-only persistence through SQLAlchemy.
- Internal match stub: fake masked sample matching, not connected to AmEx.

```mermaid
flowchart LR
  Analyst["Analyst"] --> GPT1["Merchant Risk Discovery GPT"]
  Analyst --> GPT2["AmEx Acceptance & Linkage GPT"]
  GPT1 -->|"Action: store/compare/report only"| API["FastAPI Backend"]
  GPT2 -->|"Action: store evidence/linkage only"| API
  API --> DB["SQLite Local DB"]
  API --> Stub["Fake Internal Match Stub"]
  GPT1 -. "ChatGPT web search/browsing only" .-> PublicWeb["Public Web"]
  GPT2 -. "ChatGPT web search/browsing only" .-> PublicWeb
  API -. "No crawling, scraping, fetching, or browser automation" .x PublicWeb
```

## Data Flow

1. Analyst asks Discovery GPT to research a category or region.
2. Discovery GPT uses built-in web search/browsing and records evidence-backed public observations.
3. Discovery GPT calls the backend to compare potential candidates.
4. Discovery GPT creates candidate records and extracted signals only after comparison.
5. Acceptance GPT retrieves pending candidates from the backend.
6. Acceptance GPT uses built-in web search/browsing to review passive AmEx acceptance evidence.
7. Acceptance GPT stores evidence, creates acceptance reviews, and creates internal linkage packs.
8. Acceptance GPT may call the fake internal match stub for local demonstration only.
9. Reports and exports are generated from stored records.

## Database Portability

The backend uses SQLAlchemy models and a `DATABASE_URL` setting. Local development uses SQLite. A production migration should use an AmEx-approved database, likely Postgres or an internal platform service, with managed migrations and access controls.
