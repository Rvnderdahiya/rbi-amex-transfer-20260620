from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db


router = APIRouter(tags=["evidence"])


@router.post("/evidence", response_model=schemas.EvidenceRead, status_code=status.HTTP_201_CREATED)
def create_evidence(payload: schemas.EvidenceCreate, db: Session = Depends(get_db)) -> models.Evidence:
    if not db.get(models.Candidate, payload.candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    evidence = models.Evidence(**payload.model_dump())
    db.add(evidence)
    db.commit()
    db.refresh(evidence)
    return evidence


@router.get("/candidates/{candidate_id}/evidence", response_model=list[schemas.EvidenceRead])
def get_candidate_evidence(candidate_id: int, db: Session = Depends(get_db)) -> list[models.Evidence]:
    if not db.get(models.Candidate, candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    return (
        db.query(models.Evidence)
        .filter(models.Evidence.candidate_id == candidate_id)
        .order_by(models.Evidence.created_at.asc())
        .all()
    )


@router.post("/acceptance-reviews", response_model=schemas.AcceptanceReviewRead, status_code=status.HTTP_201_CREATED)
def create_acceptance_review(payload: schemas.AcceptanceReviewCreate, db: Session = Depends(get_db)) -> models.AcceptanceReview:
    if not db.get(models.Candidate, payload.candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    review = models.AcceptanceReview(**payload.model_dump())
    db.add(review)
    db.commit()
    db.refresh(review)
    return review


@router.get("/candidates/{candidate_id}/acceptance-review", response_model=schemas.AcceptanceReviewRead)
def get_latest_acceptance_review(candidate_id: int, db: Session = Depends(get_db)) -> models.AcceptanceReview:
    if not db.get(models.Candidate, candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    review = (
        db.query(models.AcceptanceReview)
        .filter(models.AcceptanceReview.candidate_id == candidate_id)
        .order_by(models.AcceptanceReview.created_at.desc())
        .first()
    )
    if not review:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Acceptance review not found.")
    return review
