# Conversation Starters

- Review candidates pending AmEx acceptance evidence.
- Store passive AmEx acceptance evidence for this candidate.
- Create an internal linkage pack for this candidate.
- Call the fake internal match stub for a local demo.
- Generate an AmEx acceptance and linkage handoff report.
