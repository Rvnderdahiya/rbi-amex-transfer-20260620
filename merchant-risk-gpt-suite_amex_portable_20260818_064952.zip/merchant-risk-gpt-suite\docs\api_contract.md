# API Contract

All endpoints use JSON. All endpoints except `GET /health` require `X-API-Key`.

| Method | Path | Purpose | Crawling Behavior |
| --- | --- | --- | --- |
| GET | `/health` | Service health check | None |
| POST | `/runs` | Create monthly/ad hoc run | None |
| GET | `/runs` | List runs | None |
| GET | `/runs/{run_id}` | Get run | None |
| PATCH | `/runs/{run_id}` | Update run | None |
| POST | `/candidates` | Store candidate supplied by GPT/analyst | None |
| GET | `/candidates` | List candidates, optionally pending acceptance review | None |
| GET | `/candidates/{candidate_id}` | Get candidate | None |
| PATCH | `/candidates/{candidate_id}` | Update candidate | None |
| POST | `/candidates/compare` | Compare supplied candidate fields against registry | None |
| POST | `/candidates/{candidate_id}/signals` | Store extracted signals | None |
| GET | `/candidates/{candidate_id}/signals` | List extracted signals | None |
| POST | `/evidence` | Store supplied evidence summary | None |
| GET | `/candidates/{candidate_id}/evidence` | List stored evidence | None |
| POST | `/acceptance-reviews` | Store passive acceptance review | None |
| GET | `/candidates/{candidate_id}/acceptance-review` | Get latest acceptance review | None |
| POST | `/linkage-packs` | Create internal linkage pack | None |
| GET | `/candidates/{candidate_id}/linkage-pack` | Get latest linkage pack | None |
| POST | `/internal-match` | Fake masked internal match stub | None |
| POST | `/reports` | Create report from stored data | None |
| GET | `/reports/{report_id}` | Get report | None |
| GET | `/runs/{run_id}/reports` | List reports for run | None |
| POST | `/exports/run/{run_id}` | Export stored run JSON | None |

The API may accept URL strings as stored evidence fields, but it never dereferences, fetches, crawls, scrapes, or validates those URLs against the public web.
