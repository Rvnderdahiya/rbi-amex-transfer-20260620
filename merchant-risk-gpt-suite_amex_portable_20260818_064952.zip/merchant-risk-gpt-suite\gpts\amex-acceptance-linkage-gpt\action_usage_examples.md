# Action Usage Examples

## List Candidates Pending Acceptance Review

Use `listCandidatesPendingAcceptanceReview` with `needs_acceptance_review=true`.

## Create Evidence

```json
{
  "candidate_id": 1,
  "evidence_type": "amex_text",
  "evidence_level": "L1",
  "evidence_summary": "GPT browsing observed payment text indicating American Express is accepted. No transaction attempted.",
  "source_url": "https://example-bet.test/payments",
  "artifact_reference": "analyst-note-2026-08-17",
  "observed_at": "2026-08-17T18:00:00Z"
}
```

## Create Acceptance Review

```json
{
  "candidate_id": 1,
  "amex_acceptance_score": 0.72,
  "highest_evidence_level": "L1",
  "review_summary": "Passive text evidence indicates possible AmEx acceptance. No transaction attempted.",
  "recommended_next_step": "Prepare internal linkage pack for approved internal review."
}
```

## Create Linkage Pack

```json
{
  "candidate_id": 1,
  "priority": "P1",
  "exact_search_terms_json": ["example-bet.test", "support@example-bet.test"],
  "fuzzy_search_terms_json": ["Example Bet", "ExampleBet"],
  "transactional_search_suggestions_json": ["MCC mismatch", "aggregator/sub-merchant route"],
  "extracted_signals_json": [
    {"signal_type": "domain", "signal_value": "example-bet.test"},
    {"signal_type": "email", "signal_value": "support@example-bet.test"}
  ],
  "match_rationale": "High activity confidence and passive AmEx acceptance evidence."
}
```

## Call Fake Internal Match Stub

```json
{
  "linkage_pack_id": 1,
  "extracted_signals_json": [
    {"signal_type": "domain", "signal_value": "example-bet.test"}
  ]
}
```
