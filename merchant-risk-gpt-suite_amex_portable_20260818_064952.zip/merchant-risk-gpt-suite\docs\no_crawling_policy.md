# No Crawling Policy

## Policy

No AmEx-created Python crawler is allowed. No AmEx-created web crawling API is allowed. No programmatic scraping backend is allowed.

This project must not create or run:

- Public website crawlers
- Public website scrapers
- URL fetchers for candidate pages
- Browser automation
- Automated checkout
- Playwright flows
- Selenium flows
- Scrapy spiders
- Requests-based page crawlers
- Any automated public web data collection

## Allowed Discovery Channel

External discovery may happen only through the Custom GPT's built-in web search or browsing capability, under analyst supervision.

## Allowed Backend Behavior

The backend may:

- Store candidate records
- Store extracted signals
- Compare and deduplicate candidates
- Store evidence summaries
- Validate scores and enum values
- Create internal linkage packs
- Generate reports
- Export stored JSON
- Call the fake local internal matching stub

The backend may accept URL strings for storage and reporting. It must not dereference those URLs.

## Validation

Before porting, inspect the backend code and route descriptions to confirm there is no crawler, scraper, browser automation, external page retrieval, or automated public web collection capability.
