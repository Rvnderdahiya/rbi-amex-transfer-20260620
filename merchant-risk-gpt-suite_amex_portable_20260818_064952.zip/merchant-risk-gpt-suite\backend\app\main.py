from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI

from app.database import init_db
from app.deps import require_api_key
from app.routers import candidates, evidence, health, internal_match, reports, runs


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    init_db()
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="Merchant Risk GPT Suite API",
        version="0.1.0",
        description=(
            "Storage, deduplication, evidence, reporting, and fake internal matching APIs for a local "
            "merchant prohibited-activity monitoring prototype. The API does not crawl, scrape, browse, "
            "automate checkout, or retrieve public websites."
        ),
        lifespan=lifespan,
    )

    app.include_router(health.router)
    protected_dependencies = [Depends(require_api_key)]
    app.include_router(runs.router, dependencies=protected_dependencies)
    app.include_router(candidates.router, dependencies=protected_dependencies)
    app.include_router(evidence.router, dependencies=protected_dependencies)
    app.include_router(internal_match.router, dependencies=protected_dependencies)
    app.include_router(reports.router, dependencies=protected_dependencies)

    return app


app = create_app()
