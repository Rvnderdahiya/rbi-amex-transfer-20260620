import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app


@pytest.fixture()
def client():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        future=True,
    )
    testing_session_local = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = testing_session_local()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def headers():
    return {"X-API-Key": "change-me"}


@pytest.fixture()
def create_run(client, headers):
    def _create_run():
        response = client.post(
            "/runs",
            headers=headers,
            json={
                "run_month": "2026-08",
                "run_type": "monthly_incremental",
                "region": "India",
                "created_by": "pytest@example.test",
                "notes": "Fake test run.",
                "status": "in_progress",
            },
        )
        assert response.status_code == 201, response.text
        return response.json()

    return _create_run


@pytest.fixture()
def create_candidate(client, headers, create_run):
    def _create_candidate(**overrides):
        run = create_run()
        payload = {
            "run_id": run["id"],
            "canonical_domain": "example-bet.test",
            "candidate_url": "https://example-bet.test",
            "business_name_detected": "Example Bet",
            "suspected_category": "online betting/gambling",
            "activity_confidence": 0.86,
            "activity_risk_level": "high",
            "status": "new",
            "first_seen": "2026-08-17",
            "last_seen": "2026-08-17",
            "source_summary": "Fake evidence-backed public observation.",
            "gpt_discovery_notes": "No backend crawling.",
            "signals": [
                {
                    "signal_type": "domain",
                    "signal_value": "example-bet.test",
                    "confidence": 1,
                    "source_note": "Fake public observation.",
                },
                {
                    "signal_type": "email",
                    "signal_value": "support@example-bet.test",
                    "confidence": 0.8,
                    "source_note": "Fake public observation.",
                },
                {
                    "signal_type": "phone",
                    "signal_value": "+91 99900 01111",
                    "confidence": 0.8,
                    "source_note": "Fake public observation.",
                },
            ],
        }
        payload.update(overrides)
        response = client.post("/candidates", headers=headers, json=payload)
        assert response.status_code == 201, response.text
        return response.json()

    return _create_candidate
