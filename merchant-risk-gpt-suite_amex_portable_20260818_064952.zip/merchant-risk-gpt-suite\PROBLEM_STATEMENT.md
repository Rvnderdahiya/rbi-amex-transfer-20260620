# Problem Statement

Business and compliance teams need a repeatable way to identify public external merchants that may be connected to prohibited or high-risk activities, record evidence-backed observations, and prepare internal search packages for approved AmEx teams.

The workflow has three controlled phases:

1. External discovery through a Custom GPT using only ChatGPT built-in web search or browsing.
2. Passive AmEx acceptance evidence review through a second Custom GPT using only ChatGPT built-in web search or browsing.
3. Backend storage, deduplication, scoring, reporting, and optional fake internal matching for prototype demonstrations.

The backend is intentionally not a crawler. It receives manually reviewed or GPT-summarized observations and stores structured records. It must never retrieve public web pages or automate web sessions.

The prototype uses fake sample data only and is designed to be portable to an approved American Express environment after formal reviews.
