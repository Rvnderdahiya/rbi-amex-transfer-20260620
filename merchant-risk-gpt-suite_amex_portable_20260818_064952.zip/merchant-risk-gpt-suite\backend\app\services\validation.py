from __future__ import annotations

import re
from difflib import SequenceMatcher
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse


TRACKING_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "gclid", "fbclid"}
PUBLIC_SUFFIX_HINTS = {"co", "com", "net", "org", "gov", "ac"}


def normalize_domain(value: str) -> str:
    raw = (value or "").strip().lower()
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = parsed.netloc or parsed.path.split("/")[0]
    host = host.split("@")[-1].split(":")[0].strip(".")
    if host.startswith("www."):
        host = host[4:]
    return host


def root_domain(domain: str) -> str:
    host = normalize_domain(domain)
    parts = [part for part in host.split(".") if part]
    if len(parts) <= 2:
        return host
    if len(parts) >= 3 and parts[-2] in PUBLIC_SUFFIX_HINTS and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def normalize_url(value: str) -> str:
    raw = (value or "").strip()
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    scheme = (parsed.scheme or "https").lower()
    host = normalize_domain(parsed.netloc or parsed.path.split("/")[0])
    path = parsed.path
    if not parsed.netloc and "/" in parsed.path:
        path = "/" + "/".join(parsed.path.split("/")[1:])
    path = re.sub(r"/+", "/", path).rstrip("/") or "/"
    query_pairs = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True) if k.lower() not in TRACKING_PARAMS]
    query = urlencode(sorted(query_pairs))
    return urlunparse((scheme, host, path, "", query, ""))


def normalize_email(value: str) -> str:
    return (value or "").strip().lower()


def normalize_phone(value: str) -> str:
    digits = re.sub(r"\D+", "", value or "")
    if len(digits) > 10 and digits.startswith("91"):
        digits = digits[-10:]
    return digits


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", (value or "").lower())).strip()


def fuzzy_similarity(left: str | None, right: str | None) -> float:
    left_norm = normalize_text(left or "")
    right_norm = normalize_text(right or "")
    if not left_norm or not right_norm:
        return 0.0
    return SequenceMatcher(None, left_norm, right_norm).ratio()


def normalize_signal(signal_type: str, signal_value: str) -> str:
    if signal_type == "email":
        return normalize_email(signal_value)
    if signal_type == "phone":
        return normalize_phone(signal_value)
    if signal_type == "domain":
        return normalize_domain(signal_value)
    if signal_type == "url":
        return normalize_url(signal_value)
    return normalize_text(signal_value)
