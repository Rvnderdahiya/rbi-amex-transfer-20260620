from __future__ import annotations

from sqlalchemy.orm import Session

from app import models, schemas
from app.services.validation import (
    fuzzy_similarity,
    normalize_domain,
    normalize_email,
    normalize_phone,
    normalize_signal,
    normalize_url,
    root_domain,
)


def _signal_index(signals: list[schemas.SignalInput]) -> dict[str, set[str]]:
    index: dict[str, set[str]] = {}
    for signal in signals:
        value = normalize_signal(signal.signal_type.value, signal.signal_value)
        if value:
            index.setdefault(signal.signal_type.value, set()).add(value)
    return index


def _existing_signal_index(candidate: models.Candidate) -> dict[str, set[str]]:
    index: dict[str, set[str]] = {}
    for signal in candidate.signals:
        value = normalize_signal(signal.signal_type.value, signal.signal_value)
        if value:
            index.setdefault(signal.signal_type.value, set()).add(value)
    return index


def compare_candidate(db: Session, request: schemas.CandidateCompareRequest) -> schemas.CandidateCompareResponse:
    incoming_domain = normalize_domain(request.canonical_domain or "")
    incoming_url = normalize_url(request.candidate_url or "") if request.candidate_url else ""
    incoming_root = root_domain(incoming_domain)
    incoming_signals = _signal_index(request.signals)
    incoming_emails = incoming_signals.get("email", set())
    incoming_phones = incoming_signals.get("phone", set())

    candidates = db.query(models.Candidate).all()
    scored: list[tuple[int, float, list[str]]] = []

    for candidate in candidates:
        score = 0.0
        reasons: list[str] = []

        existing_domain = normalize_domain(candidate.canonical_domain)
        existing_url = normalize_url(candidate.candidate_url)

        if incoming_domain and incoming_domain == existing_domain:
            score += 60
            reasons.append("exact canonical domain match")

        if incoming_url and incoming_url == existing_url:
            score += 55
            reasons.append("exact normalized URL match")

        if incoming_domain and incoming_root and incoming_root == root_domain(existing_domain) and incoming_domain != existing_domain:
            score += 30
            reasons.append("same root domain")

        name_similarity = fuzzy_similarity(request.business_name_detected, candidate.business_name_detected)
        if name_similarity >= 0.85:
            score += 35
            reasons.append(f"high business name similarity ({name_similarity:.2f})")
        elif name_similarity >= 0.70:
            score += 20
            reasons.append(f"medium business name similarity ({name_similarity:.2f})")

        existing_signals = _existing_signal_index(candidate)
        existing_emails = existing_signals.get("email", set())
        existing_phones = existing_signals.get("phone", set())
        if incoming_emails and incoming_emails.intersection(existing_emails):
            score += 50
            reasons.append("exact email signal match")
        if incoming_phones and incoming_phones.intersection(existing_phones):
            score += 50
            reasons.append("exact phone signal match")

        overlap_count = 0
        for signal_type, values in incoming_signals.items():
            overlap_count += len(values.intersection(existing_signals.get(signal_type, set())))
        if overlap_count:
            overlap_score = min(30, overlap_count * 10)
            score += overlap_score
            reasons.append(f"{overlap_count} normalized signal overlap(s)")

        if score > 0:
            scored.append((candidate.id, min(score, 100.0), reasons))

    scored.sort(key=lambda item: item[1], reverse=True)
    possible_ids = [candidate_id for candidate_id, score, _ in scored if score >= 30]
    best_score = scored[0][1] if scored else 0.0
    best_reasons = scored[0][2] if scored else []

    if best_score >= 80:
        recommended_status = "unchanged"
    elif best_score >= 60:
        recommended_status = "changed"
    elif possible_ids:
        recommended_status = "possible_duplicate"
    else:
        recommended_status = "new"

    return schemas.CandidateCompareResponse(
        is_duplicate=best_score >= 60,
        possible_existing_candidate_ids=possible_ids,
        dedupe_score=best_score,
        match_reasons=best_reasons,
        recommended_status=recommended_status,
    )
