def test_evidence_and_acceptance_review_creation(client, headers, create_candidate):
    candidate = create_candidate()

    evidence_response = client.post(
        "/evidence",
        headers=headers,
        json={
            "candidate_id": candidate["id"],
            "evidence_type": "amex_text",
            "evidence_level": "L1",
            "evidence_summary": "Fake passive text says American Express is accepted. No transaction attempted.",
            "source_url": "https://example-bet.test/payments",
            "artifact_reference": "fake-note-001",
            "observed_at": "2026-08-17T12:00:00Z",
        },
    )

    assert evidence_response.status_code == 201, evidence_response.text
    assert evidence_response.json()["evidence_level"] == "L1"

    review_response = client.post(
        "/acceptance-reviews",
        headers=headers,
        json={
            "candidate_id": candidate["id"],
            "amex_acceptance_score": 0.72,
            "highest_evidence_level": "L1",
            "review_summary": "Fake passive evidence indicates possible AmEx acceptance.",
            "recommended_next_step": "Create internal linkage pack for review.",
        },
    )

    assert review_response.status_code == 201, review_response.text
    assert review_response.json()["amex_acceptance_score"] == 0.72

    list_response = client.get(f"/candidates/{candidate['id']}/evidence", headers=headers)
    assert list_response.status_code == 200
    assert len(list_response.json()) == 1
