from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db


router = APIRouter(tags=["runs"])


@router.post("/runs", response_model=schemas.RunRead, status_code=status.HTTP_201_CREATED)
def create_run(payload: schemas.RunCreate, db: Session = Depends(get_db)) -> models.Run:
    run = models.Run(**payload.model_dump())
    db.add(run)
    db.commit()
    db.refresh(run)
    return run


@router.get("/runs", response_model=list[schemas.RunRead])
def list_runs(db: Session = Depends(get_db)) -> list[models.Run]:
    return db.query(models.Run).order_by(models.Run.created_at.desc()).all()


@router.get("/runs/{run_id}", response_model=schemas.RunRead)
def get_run(run_id: int, db: Session = Depends(get_db)) -> models.Run:
    run = db.get(models.Run, run_id)
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")
    return run


@router.patch("/runs/{run_id}", response_model=schemas.RunRead)
def update_run(run_id: int, payload: schemas.RunUpdate, db: Session = Depends(get_db)) -> models.Run:
    run = db.get(models.Run, run_id)
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(run, field, value)
    db.commit()
    db.refresh(run)
    return run
