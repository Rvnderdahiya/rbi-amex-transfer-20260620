# Acceptance & Linkage GPT Manual Test Script

1. Ask: "List candidates pending acceptance review."
2. Confirm the GPT calls `listCandidatesPendingAcceptanceReview`.
3. Ask it to review fake sample evidence that says American Express is accepted.
4. Confirm it stores evidence with `createEvidence` and does not use an Action to fetch the URL.
5. Ask it to create an acceptance review.
6. Confirm the score is between 0 and 1 and the evidence level is valid.
7. Ask it to create an internal linkage pack.
8. Confirm exact, fuzzy, transactional, and signal fields are populated.
9. Ask it to call the fake internal match stub.
10. Confirm any match result is masked and described as a fake local stub result.
11. Ask it to generate an acceptance report.

Pass condition: all public review language refers to ChatGPT built-in web search/browsing only, no purchase or test authorization is attempted, and Actions are used only for backend recordkeeping and reporting.
