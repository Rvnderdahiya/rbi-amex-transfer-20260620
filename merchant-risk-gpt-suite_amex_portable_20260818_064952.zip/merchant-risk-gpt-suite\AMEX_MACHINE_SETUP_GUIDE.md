# AmEx Machine Setup Guide

This guide explains exactly how to get `merchant-risk-gpt-suite` working after you move it to an approved American Express machine or development environment.

Important: this project is a prototype. Use fake/sample data only until InfoSec, Legal, Compliance, Privacy, and Architecture approve real data handling.

## 1. What You Need Before Starting

Confirm these items before you run anything:

1. You have the project zip file, for example `merchant-risk-gpt-suite_amex_portable_20260818.zip`.
2. You are on an approved AmEx machine or approved AmEx development environment.
3. You have permission to run Python applications locally.
4. You have permission to create a local project folder.
5. You have internet or internal package repository access for Python packages, or an approved internal mirror.
6. You have a way to expose the API to Custom GPT Actions if GPT Builder must call it.
7. You know whether AmEx wants this run as:
   - local Python process,
   - Docker container,
   - internal development server,
   - or approved platform deployment.

Do not use real AmEx data on a personal laptop. Do not store cardholder data. Do not store full payment card numbers.

## 2. Copy The Zip To The AmEx Machine

If downloading from GitHub:

1. Open the GitHub repository or release page where the zip was uploaded.
2. Download `merchant-risk-gpt-suite_amex_portable_20260818.zip`.
3. Save it to an approved working folder, for example:

```powershell
C:\Users\<your-id>\Documents\merchant-risk-gpt-suite
```

If AmEx requires a specific project path, use that approved path instead.

## 3. Extract The Zip

1. Open File Explorer.
2. Go to the folder where the zip was downloaded.
3. Right-click the zip file.
4. Select `Extract All...`.
5. Choose an approved destination folder.
6. After extraction, confirm you can see:

```text
merchant-risk-gpt-suite/
  README.md
  AMEX_MACHINE_SETUP_GUIDE.md
  backend/
  gpts/
  docs/
```

PowerShell alternative:

```powershell
Expand-Archive -Path .\merchant-risk-gpt-suite_amex_portable_20260818.zip -DestinationPath .\merchant-risk-gpt-suite_unpack -Force
cd .\merchant-risk-gpt-suite_unpack\merchant-risk-gpt-suite
```

If the extracted folder contains one extra nested folder, enter the inner `merchant-risk-gpt-suite` folder before continuing.

## 4. Confirm Python Is Installed

Open PowerShell and run:

```powershell
python --version
```

Expected:

```text
Python 3.11.x
```

Python 3.11 is recommended because local validation used Python 3.11.9.

If Python is not available:

1. Do not install random software from the internet.
2. Use the AmEx-approved software center, internal package source, or platform image.
3. Ask the AmEx desktop/platform team for Python 3.11.

## 5. Enter The Project Folder

Use the actual path where you extracted the project.

Example:

```powershell
cd C:\Users\<your-id>\Documents\merchant-risk-gpt-suite
```

Confirm files are present:

```powershell
dir
```

You should see:

```text
README.md
requirements.txt
backend
gpts
docs
```

## 6. Create A Python Virtual Environment

From inside the project folder:

```powershell
python -m venv .venv
```

Activate it:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use the AmEx-approved execution policy process. A temporary session-only command is:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Only use that if AmEx policy allows it.

After activation, your prompt usually shows:

```text
(.venv)
```

## 7. Install Python Dependencies

Upgrade pip:

```powershell
python -m pip install --upgrade pip
```

Install packages:

```powershell
pip install -r requirements.txt
```

If public internet package install is blocked, use AmEx-approved internal package mirrors. The dependency list is in:

```text
requirements.txt
```

Main packages:

- FastAPI
- Uvicorn
- SQLAlchemy
- Pydantic
- pytest
- PyYAML

## 8. Create The Local Environment File

Copy the example file:

```powershell
Copy-Item .env.example .env
```

Open `.env` in an approved editor and set values:

```text
APP_ENV=local
APP_API_KEY=<choose-a-secret-api-key>
DATABASE_URL=sqlite:///./merchant_risk.db
LOG_LEVEL=INFO
```

For a quick local smoke test, `change-me` works only if you leave it as-is. For AmEx use, replace it with an approved secret value.

Do not commit `.env` to GitHub. Do not share the API key in chat or email.

## 9. Set Python Path For Local Run

From the project folder:

```powershell
$env:PYTHONPATH = "$PWD\backend"
```

This tells Python where the backend package is.

## 10. Run Automated Tests

Run:

```powershell
python -m pytest
```

Expected:

```text
6 passed
```

If tests fail, do not port further. Save the output and resolve the failure first.

## 11. Start The Backend API Locally

From the same activated virtual environment:

```powershell
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Expected output includes:

```text
Uvicorn running on http://127.0.0.1:8000
```

Leave this PowerShell window open while testing. The API stops if you close the window or press `Ctrl+C`.

## 12. Confirm Health Check Works

Open a second PowerShell window.

Go to the project folder and run:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
```

Expected:

```text
status  : ok
service : merchant-risk-gpt-suite
policy  : storage-and-analysis-only-no-crawling
```

## 13. Test A Protected API Endpoint

Use the same API key from `.env`.

Example if the key is `change-me`:

```powershell
$headers = @{ "X-API-Key" = "change-me" }
Invoke-RestMethod http://127.0.0.1:8000/runs -Headers $headers
```

Expected:

```text
An empty list, or stored runs if records already exist.
```

If you get `401`, the API key in your header does not match `.env`.

## 14. Load Sample Fake Data Manually

This project does not include a crawler. Sample records are JSON files only.

Create a run:

```powershell
$headers = @{ "X-API-Key" = "change-me" }
$runPayload = Get-Content .\backend\app\seed\sample_run.json -Raw
$run = Invoke-RestMethod -Method Post http://127.0.0.1:8000/runs -Headers $headers -ContentType "application/json" -Body $runPayload
$run
```

The returned object includes `id`. Save that ID.

Create candidates from `sample_candidates.json` only after comparing them if you are doing a realistic workflow. The Discovery GPT should normally do this through Actions.

## 15. Open API Documentation Locally

In a browser on the AmEx machine, open:

```text
http://127.0.0.1:8000/docs
```

This shows Swagger UI for local development only.

You can also open:

```text
http://127.0.0.1:8000/openapi.json
```

## 16. Configure Custom GPT 1: Merchant Risk Discovery GPT

The exact GPT Builder UI may vary by plan and workspace.

1. Open ChatGPT in the approved workspace.
2. Go to `GPTs`.
3. Choose `Create`.
4. Name the GPT:

```text
Merchant Risk Discovery GPT
```

5. Open this file from the project:

```text
gpts/merchant-risk-discovery-gpt/instructions.md
```

6. Copy the full contents.
7. Paste into the GPT Builder `Instructions` field.
8. Enable web search/browsing capability.
9. Add an Action.
10. Open this file:

```text
gpts/merchant-risk-discovery-gpt/action_openapi.yaml
```

11. Copy the full YAML.
12. Paste it into the Action schema field.
13. Replace the `servers.url` placeholder with the approved reachable backend URL.

For local development, the backend must be reachable by GPT Actions. `127.0.0.1` on your machine is usually not reachable by ChatGPT. Use an approved internal URL, approved development tunnel, or AmEx-hosted development endpoint.

14. Configure Action authentication:

```text
Header name: X-API-Key
Header value: the APP_API_KEY value from the approved secrets source
```

15. Save the GPT.
16. Test with:

```text
Create a monthly India discovery run for August 2026 using fake sample data only.
```

17. Confirm it uses Actions only for storing, comparing, deduping, reporting, and exporting.

## 17. Configure Custom GPT 2: AmEx Acceptance & Linkage GPT

1. In ChatGPT, create another GPT.
2. Name it:

```text
AmEx Acceptance & Linkage GPT
```

3. Open:

```text
gpts/amex-acceptance-linkage-gpt/instructions.md
```

4. Copy the full contents.
5. Paste into GPT Builder `Instructions`.
6. Enable web search/browsing capability.
7. Add an Action.
8. Open:

```text
gpts/amex-acceptance-linkage-gpt/action_openapi.yaml
```

9. Copy the full YAML.
10. Paste it into the Action schema field.
11. Replace `servers.url` with the same approved reachable backend URL.
12. Configure Action authentication:

```text
Header name: X-API-Key
Header value: approved APP_API_KEY value
```

13. Save the GPT.
14. Test with:

```text
List candidates pending AmEx acceptance review.
```

15. Confirm it does not ask the backend to fetch URLs.

## 18. Critical Network Detail For GPT Actions

Custom GPT Actions cannot call a backend that exists only on your laptop loopback address unless the GPT runtime can reach it.

These usually do not work for GPT Actions:

```text
http://127.0.0.1:8000
http://localhost:8000
```

Use one of these approved options:

1. AmEx-hosted internal development URL.
2. Approved API gateway route.
3. Approved internal tunnel.
4. Approved container/platform endpoint.

Do not expose the service publicly unless AmEx approves that route.

## 19. Docker Option

Only use Docker if it is approved and installed.

Create `.env`:

```powershell
Copy-Item .env.example .env
```

Edit `.env`, then run:

```powershell
docker compose up --build
```

Health check:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
```

Stop Docker:

```powershell
docker compose down
```

## 20. Postgres Or Approved Database Migration

SQLite is local only. For AmEx environment, replace:

```text
DATABASE_URL=sqlite:///./merchant_risk.db
```

with an approved database URL, for example an approved Postgres-style URL:

```text
DATABASE_URL=postgresql+psycopg://<user>:<password>@<host>:<port>/<database>
```

Do not hardcode database passwords. Use an enterprise secrets manager.

The current project does not include production migration tooling. Before production, add approved schema migrations such as Alembic or the AmEx standard migration mechanism.

## 21. Replace The Internal Match Stub

The endpoint:

```text
POST /internal-match
```

is fake. It returns masked sample data only.

Before production:

1. Identify the approved AmEx internal merchant/entity matching API.
2. Get API access approved.
3. Replace `backend/app/services/internal_match_stub.py`.
4. Keep responses masked unless policy allows more.
5. Add audit logging.
6. Add tests using fake fixtures only.

## 22. What Must Never Be Added

Do not add:

- Python crawlers
- Scrapers
- Requests-based page fetching
- httpx-based page fetching
- Playwright
- Selenium
- Scrapy
- Browser automation
- Automated checkout
- Live transaction testing
- Full payment card number storage
- Cardholder data storage

Backend APIs can store source URL strings, but must not fetch those URLs.

## 23. Minimum Go/No-Go Checklist

Before saying it works on the AmEx machine:

1. Zip extracted successfully.
2. Python 3.11 available.
3. Virtual environment created.
4. Dependencies installed.
5. `.env` created with approved secret.
6. Tests pass.
7. Backend starts.
8. `/health` returns `ok`.
9. Protected endpoint works with `X-API-Key`.
10. Action OpenAPI files load in GPT Builder.
11. Both GPTs have web search/browsing enabled.
12. GPT Action URL is reachable by GPT Builder.
13. GPT Actions authenticate successfully.
14. Discovery GPT can create/list runs and compare candidates.
15. Acceptance GPT can list candidates and store evidence.
16. No backend crawling capability has been added.

## 24. Troubleshooting

### Problem: `python` is not recognized

Use AmEx-approved Python installation or platform image.

### Problem: virtual environment activation is blocked

Use AmEx-approved PowerShell execution policy process. Do not bypass policy if not allowed.

### Problem: package install fails

Use internal package mirror or ask platform team for approved dependencies.

### Problem: API key returns 401

Check:

1. `.env` value for `APP_API_KEY`.
2. Header name is exactly `X-API-Key`.
3. Header value matches exactly.
4. Restart backend after changing `.env`.

### Problem: GPT Action cannot reach backend

`localhost` usually will not work from GPT Actions. Use approved internal URL, gateway, hosted environment, or approved tunnel.

### Problem: SQLite database looks empty

Check the folder where the backend was started. SQLite creates `merchant_risk.db` relative to the current working directory.

### Problem: port 8000 is already in use

Run on a different approved port:

```powershell
uvicorn app.main:app --host 127.0.0.1 --port 8010
```

Then update the Action schema server URL if needed.

## 25. Final Production Reminder

This is ready only for approved AmEx development review. It is not production-ready until AmEx completes security, legal, compliance, privacy, architecture, secrets, database, monitoring, audit, RBAC, TLS, network, and internal matching integration work.
