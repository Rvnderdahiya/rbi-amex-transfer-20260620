from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services.report_builder import build_report_summary, export_run


router = APIRouter(tags=["reports"])


@router.post("/reports", response_model=schemas.ReportRead, status_code=status.HTTP_201_CREATED)
def create_report(payload: schemas.ReportCreate, db: Session = Depends(get_db)) -> models.Report:
    run = db.get(models.Run, payload.run_id)
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")
    summary = payload.summary_json or build_report_summary(db, payload.run_id, payload.report_type)
    title = payload.title or f"{payload.report_type.value.replace('_', ' ').title()} Report - {run.run_month} - {run.region}"
    report = models.Report(run_id=payload.run_id, report_type=payload.report_type, title=title, summary_json=summary)
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


@router.get("/reports/{report_id}", response_model=schemas.ReportRead)
def get_report(report_id: int, db: Session = Depends(get_db)) -> models.Report:
    report = db.get(models.Report, report_id)
    if not report:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found.")
    return report


@router.get("/runs/{run_id}/reports", response_model=list[schemas.ReportRead])
def get_run_reports(run_id: int, db: Session = Depends(get_db)) -> list[models.Report]:
    if not db.get(models.Run, run_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")
    return db.query(models.Report).filter(models.Report.run_id == run_id).order_by(models.Report.created_at.desc()).all()


@router.post("/exports/run/{run_id}")
def export_run_json(run_id: int, db: Session = Depends(get_db)) -> dict:
    try:
        return export_run(db, run_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
