from __future__ import annotations

import enum
from datetime import date, datetime

from sqlalchemy import Date, DateTime, Enum, Float, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utcnow() -> datetime:
    return datetime.utcnow()


class RunType(str, enum.Enum):
    baseline = "baseline"
    monthly_incremental = "monthly_incremental"
    ad_hoc = "ad_hoc"
    quarterly_refresh = "quarterly_refresh"


class RunStatus(str, enum.Enum):
    draft = "draft"
    in_progress = "in_progress"
    review = "review"
    completed = "completed"
    archived = "archived"


class CandidateStatus(str, enum.Enum):
    new = "new"
    changed = "changed"
    unchanged = "unchanged"
    reopened = "reopened"
    offline = "offline"
    false_positive = "false_positive"
    escalated = "escalated"


class SignalType(str, enum.Enum):
    domain = "domain"
    url = "url"
    business_name = "business_name"
    legal_name = "legal_name"
    phone = "phone"
    email = "email"
    address = "address"
    gstin = "gstin"
    cin = "cin"
    pan = "pan"
    app_name = "app_name"
    app_developer = "app_developer"
    social_handle = "social_handle"
    payment_gateway_clue = "payment_gateway_clue"
    descriptor = "descriptor"
    other = "other"


class EvidenceType(str, enum.Enum):
    page_text_summary = "page_text_summary"
    search_result_summary = "search_result_summary"
    screenshot_reference = "screenshot_reference"
    payment_page_text = "payment_page_text"
    amex_logo = "amex_logo"
    amex_text = "amex_text"
    card_network_list = "card_network_list"
    checkout_observation = "checkout_observation"
    other = "other"


class EvidenceLevel(str, enum.Enum):
    none = "none"
    L0 = "L0"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"


class Priority(str, enum.Enum):
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"
    P4 = "P4"


class MatchStatus(str, enum.Enum):
    not_checked = "not_checked"
    no_match = "no_match"
    possible_match_found = "possible_match_found"
    strong_match_found = "strong_match_found"
    error = "error"


class ReportType(str, enum.Enum):
    discovery = "discovery"
    acceptance = "acceptance"
    monthly_summary = "monthly_summary"


class Run(Base):
    __tablename__ = "runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    run_month: Mapped[str] = mapped_column(String(7), index=True)
    run_type: Mapped[RunType] = mapped_column(Enum(RunType), default=RunType.monthly_incremental)
    region: Mapped[str] = mapped_column(String(100), default="global", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    created_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[RunStatus] = mapped_column(Enum(RunStatus), default=RunStatus.draft)

    candidates: Mapped[list[Candidate]] = relationship(back_populates="run", cascade="all, delete-orphan")
    reports: Mapped[list[Report]] = relationship(back_populates="run", cascade="all, delete-orphan")


class Candidate(Base):
    __tablename__ = "candidates"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id"), index=True)
    canonical_domain: Mapped[str] = mapped_column(String(255), index=True)
    candidate_url: Mapped[str] = mapped_column(Text)
    business_name_detected: Mapped[str | None] = mapped_column(String(500), nullable=True, index=True)
    suspected_category: Mapped[str] = mapped_column(String(255), index=True)
    activity_confidence: Mapped[float] = mapped_column(Float)
    activity_risk_level: Mapped[str] = mapped_column(String(50))
    status: Mapped[CandidateStatus] = mapped_column(Enum(CandidateStatus), default=CandidateStatus.new, index=True)
    first_seen: Mapped[date | None] = mapped_column(Date, nullable=True)
    last_seen: Mapped[date | None] = mapped_column(Date, nullable=True)
    source_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    gpt_discovery_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    run: Mapped[Run] = relationship(back_populates="candidates")
    signals: Mapped[list[ExtractedSignal]] = relationship(back_populates="candidate", cascade="all, delete-orphan")
    evidence: Mapped[list[Evidence]] = relationship(back_populates="candidate", cascade="all, delete-orphan")
    acceptance_reviews: Mapped[list[AcceptanceReview]] = relationship(back_populates="candidate", cascade="all, delete-orphan")
    linkage_packs: Mapped[list[InternalLinkagePack]] = relationship(back_populates="candidate", cascade="all, delete-orphan")


class ExtractedSignal(Base):
    __tablename__ = "extracted_signals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id"), index=True)
    signal_type: Mapped[SignalType] = mapped_column(Enum(SignalType), index=True)
    signal_value: Mapped[str] = mapped_column(Text, index=True)
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    source_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    candidate: Mapped[Candidate] = relationship(back_populates="signals")


class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id"), index=True)
    evidence_type: Mapped[EvidenceType] = mapped_column(Enum(EvidenceType), index=True)
    evidence_level: Mapped[EvidenceLevel] = mapped_column(Enum(EvidenceLevel), default=EvidenceLevel.none, index=True)
    evidence_summary: Mapped[str] = mapped_column(Text)
    source_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    artifact_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    observed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    candidate: Mapped[Candidate] = relationship(back_populates="evidence")


class AcceptanceReview(Base):
    __tablename__ = "acceptance_reviews"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id"), index=True)
    amex_acceptance_score: Mapped[float] = mapped_column(Float)
    highest_evidence_level: Mapped[EvidenceLevel] = mapped_column(Enum(EvidenceLevel), default=EvidenceLevel.none)
    review_summary: Mapped[str] = mapped_column(Text)
    recommended_next_step: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    candidate: Mapped[Candidate] = relationship(back_populates="acceptance_reviews")


class InternalLinkagePack(Base):
    __tablename__ = "internal_linkage_packs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id"), index=True)
    priority: Mapped[Priority] = mapped_column(Enum(Priority), default=Priority.P3, index=True)
    exact_search_terms_json: Mapped[list] = mapped_column(JSON, default=list)
    fuzzy_search_terms_json: Mapped[list] = mapped_column(JSON, default=list)
    transactional_search_suggestions_json: Mapped[list] = mapped_column(JSON, default=list)
    extracted_signals_json: Mapped[list] = mapped_column(JSON, default=list)
    match_rationale: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    candidate: Mapped[Candidate] = relationship(back_populates="linkage_packs")
    match_results: Mapped[list[InternalMatchResult]] = relationship(back_populates="linkage_pack", cascade="all, delete-orphan")


class InternalMatchResult(Base):
    __tablename__ = "internal_match_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    linkage_pack_id: Mapped[int] = mapped_column(ForeignKey("internal_linkage_packs.id"), index=True)
    match_status: Mapped[MatchStatus] = mapped_column(Enum(MatchStatus), default=MatchStatus.not_checked, index=True)
    masked_internal_reference: Mapped[str | None] = mapped_column(String(255), nullable=True)
    match_score: Mapped[float] = mapped_column(Float, default=0.0)
    matched_on_json: Mapped[list] = mapped_column(JSON, default=list)
    masked_profile_json: Mapped[dict] = mapped_column(JSON, default=dict)
    recommended_action: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    linkage_pack: Mapped[InternalLinkagePack] = relationship(back_populates="match_results")


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("runs.id"), index=True)
    report_type: Mapped[ReportType] = mapped_column(Enum(ReportType), index=True)
    title: Mapped[str] = mapped_column(String(500))
    summary_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    run: Mapped[Run] = relationship(back_populates="reports")
