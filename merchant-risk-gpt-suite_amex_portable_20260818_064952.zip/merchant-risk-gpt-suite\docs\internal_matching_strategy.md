# Internal Matching Strategy

## Purpose

Internal linkage packs help approved AmEx teams search for whether a suspicious public business maps to an internal merchant under a disguised, alternate, or aggregator/sub-merchant name.

## Exact Search Terms

Use exact terms when available:

- Domain
- URL
- Email
- Phone
- GSTIN
- CIN
- PAN if policy allows
- Legal name
- App developer
- Payment gateway merchant reference if visible

## Fuzzy Search Terms

Use fuzzy terms for possible aliases:

- Business name variants
- DBA variants
- Domain variants
- Descriptor variants
- Related names
- App or developer name variants

## Transactional Search Suggestions

These are suggestions for approved internal analytics only:

- MCC mismatch
- Generic digital services MCC
- Unusual refund ratio
- Chargeback pattern
- High-risk geography
- Transaction volume spikes
- Small-value testing
- Aggregator/sub-merchant route
- Settlement anomalies

## Prototype Stub

The local `/internal-match` endpoint is a fake masked stub. It must be replaced by an approved AmEx internal API before production use.
