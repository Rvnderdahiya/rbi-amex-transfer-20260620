def test_duplicate_comparison_detects_existing_candidate(client, headers, create_candidate):
    candidate = create_candidate()

    response = client.post(
        "/candidates/compare",
        headers=headers,
        json={
            "canonical_domain": "www.example-bet.test",
            "candidate_url": "https://example-bet.test/",
            "business_name_detected": "Example Bet",
            "signals": [
                {
                    "signal_type": "phone",
                    "signal_value": "9990001111",
                    "confidence": 0.9,
                    "source_note": "Fake duplicate phone.",
                }
            ],
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["is_duplicate"] is True
    assert candidate["id"] in body["possible_existing_candidate_ids"]
    assert body["dedupe_score"] >= 60
    assert any("domain" in reason or "phone" in reason for reason in body["match_reasons"])
