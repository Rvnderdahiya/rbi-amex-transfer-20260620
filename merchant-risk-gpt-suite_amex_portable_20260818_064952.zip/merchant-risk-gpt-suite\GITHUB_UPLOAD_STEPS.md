# GitHub Upload Steps

Use these steps to upload the portable zip to GitHub so it can be downloaded on an approved AmEx machine.

## Recommended Safety Choice

Create a private repository unless AmEx explicitly approves a public repository.

Suggested repository name:

```text
merchant-risk-gpt-suite-transfer
```

Suggested uploaded files. Use the newest matching pair in the parent folder:

```text
merchant-risk-gpt-suite_amex_portable_*.zip
merchant-risk-gpt-suite_amex_portable_*.sha256.txt
```

## Create A New Private GitHub Repository

1. Open Chrome.
2. Go to:

```text
https://github.com/Rvnderdahiya
```

3. Confirm you are signed in.
4. Click the `+` button in the top-right GitHub navigation bar.
5. Click `New repository`.
6. In `Repository name`, type:

```text
merchant-risk-gpt-suite-transfer
```

7. In `Description`, type:

```text
Portable local prototype package for merchant-risk GPT suite transfer.
```

8. Select `Private`.
9. Do not add a README if you are uploading only the zip first.
10. Do not add `.gitignore`.
11. Do not add a license.
12. Click `Create repository`.

## Upload The Zip In GitHub Web UI

1. Open the new repository.
2. If the repository is empty, click `uploading an existing file`.
3. If the repository is not empty, click `Add file`.
4. Click `Upload files`.
5. Drag the newest portable zip file into the upload box. It will be in this folder:

```text
C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring
```

6. Also drag the matching checksum file with the same timestamp and `.sha256.txt` ending.

```text
Example:
merchant-risk-gpt-suite_amex_portable_20260818_064859.zip
merchant-risk-gpt-suite_amex_portable_20260818_064859.sha256.txt
```

7. Wait until both files finish uploading.
8. In `Commit changes`, use this message:

```text
Add portable merchant risk GPT suite package
```

9. Keep `Commit directly to the main branch` selected.
10. Click `Commit changes`.
11. Confirm both files appear in the repository file list.

## Download On AmEx Machine

1. Open the repository on the AmEx machine.
2. Download the zip file.
3. Download the `.sha256.txt` checksum file.
4. Verify the checksum if AmEx policy requires it.
5. Extract the zip.
6. Open `AMEX_MACHINE_SETUP_GUIDE.md`.
7. Follow the setup guide from the top.

## Checksum

Every rebuild produces a new checksum. Use the `.sha256.txt` file that has the same timestamp as the zip you uploaded.
