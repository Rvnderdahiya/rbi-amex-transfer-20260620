from app.models import CandidateStatus, Priority


def derive_priority(
    activity_confidence: float,
    amex_acceptance_score: float,
    candidate_status: CandidateStatus | str | None = None,
) -> Priority:
    status_value = candidate_status.value if hasattr(candidate_status, "value") else candidate_status
    if status_value == CandidateStatus.false_positive.value or activity_confidence < 0.40:
        return Priority.P4
    if activity_confidence >= 0.80 and amex_acceptance_score >= 0.70:
        return Priority.P1
    if activity_confidence >= 0.65 and amex_acceptance_score >= 0.40:
        return Priority.P2
    if activity_confidence >= 0.50 or amex_acceptance_score > 0:
        return Priority.P3
    return Priority.P4
