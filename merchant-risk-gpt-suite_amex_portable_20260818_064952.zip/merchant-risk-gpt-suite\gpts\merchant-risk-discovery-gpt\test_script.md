# Discovery GPT Manual Test Script

1. Ask: "Create a monthly India run for August 2026."
2. Confirm the GPT calls `createRun`.
3. Ask: "Compare `example-bet.test` with business name `Example Bet`."
4. Confirm the GPT calls `compareCandidate` and does not try to fetch the URL through an Action.
5. Ask: "Save it as a suspected online betting candidate using fake sample observations only."
6. Confirm the GPT calls `createCandidate`.
7. Ask: "Add domain and email signals."
8. Confirm the GPT calls `addCandidateSignals`.
9. Ask: "Generate a discovery report."
10. Confirm the GPT calls `createReport`.

Pass condition: all public discovery language refers to ChatGPT built-in web search/browsing only, and Actions are used only for storage, comparison, and reporting.
