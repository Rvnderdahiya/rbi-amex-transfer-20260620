from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models import (
    CandidateStatus,
    EvidenceLevel,
    EvidenceType,
    MatchStatus,
    Priority,
    ReportType,
    RunStatus,
    RunType,
    SignalType,
)
from app.services.validation import normalize_domain, normalize_url


class RunBase(BaseModel):
    run_month: str = Field(..., pattern=r"^\d{4}-\d{2}$")
    run_type: RunType = RunType.monthly_incremental
    region: str = "global"
    created_by: str | None = None
    notes: str | None = None
    status: RunStatus = RunStatus.draft


class RunCreate(RunBase):
    pass


class RunUpdate(BaseModel):
    run_month: str | None = Field(default=None, pattern=r"^\d{4}-\d{2}$")
    run_type: RunType | None = None
    region: str | None = None
    created_by: str | None = None
    notes: str | None = None
    status: RunStatus | None = None


class RunRead(RunBase):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class SignalInput(BaseModel):
    signal_type: SignalType
    signal_value: str = Field(..., min_length=1)
    confidence: float = Field(default=1.0, ge=0, le=1)
    source_note: str | None = None


class SignalBulkCreate(BaseModel):
    signals: list[SignalInput] = Field(default_factory=list)


class ExtractedSignalRead(SignalInput):
    id: int
    candidate_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class CandidateBase(BaseModel):
    run_id: int
    canonical_domain: str = Field(..., min_length=1)
    candidate_url: str = Field(..., min_length=1)
    business_name_detected: str | None = None
    suspected_category: str = Field(..., min_length=1)
    activity_confidence: float = Field(..., ge=0, le=1)
    activity_risk_level: str = Field(..., min_length=1)
    status: CandidateStatus = CandidateStatus.new
    first_seen: date | None = None
    last_seen: date | None = None
    source_summary: str | None = None
    gpt_discovery_notes: str | None = None

    @field_validator("canonical_domain")
    @classmethod
    def canonicalize_domain(cls, value: str) -> str:
        return normalize_domain(value)

    @field_validator("candidate_url")
    @classmethod
    def canonicalize_url(cls, value: str) -> str:
        return normalize_url(value)


class CandidateCreate(CandidateBase):
    signals: list[SignalInput] = Field(default_factory=list)


class CandidateUpdate(BaseModel):
    canonical_domain: str | None = None
    candidate_url: str | None = None
    business_name_detected: str | None = None
    suspected_category: str | None = None
    activity_confidence: float | None = Field(default=None, ge=0, le=1)
    activity_risk_level: str | None = None
    status: CandidateStatus | None = None
    first_seen: date | None = None
    last_seen: date | None = None
    source_summary: str | None = None
    gpt_discovery_notes: str | None = None

    @field_validator("canonical_domain")
    @classmethod
    def canonicalize_domain(cls, value: str | None) -> str | None:
        return normalize_domain(value) if value else value

    @field_validator("candidate_url")
    @classmethod
    def canonicalize_url(cls, value: str | None) -> str | None:
        return normalize_url(value) if value else value


class CandidateRead(CandidateBase):
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class CandidateCompareRequest(BaseModel):
    canonical_domain: str | None = None
    candidate_url: str | None = None
    business_name_detected: str | None = None
    signals: list[SignalInput] = Field(default_factory=list)

    @field_validator("canonical_domain")
    @classmethod
    def canonicalize_domain(cls, value: str | None) -> str | None:
        return normalize_domain(value) if value else value

    @field_validator("candidate_url")
    @classmethod
    def canonicalize_url(cls, value: str | None) -> str | None:
        return normalize_url(value) if value else value


class CandidateCompareResponse(BaseModel):
    is_duplicate: bool
    possible_existing_candidate_ids: list[int]
    dedupe_score: float
    match_reasons: list[str]
    recommended_status: str


class EvidenceCreate(BaseModel):
    candidate_id: int
    evidence_type: EvidenceType
    evidence_level: EvidenceLevel = EvidenceLevel.none
    evidence_summary: str = Field(..., min_length=1)
    source_url: str | None = None
    artifact_reference: str | None = None
    observed_at: datetime | None = None


class EvidenceRead(EvidenceCreate):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AcceptanceReviewCreate(BaseModel):
    candidate_id: int
    amex_acceptance_score: float = Field(..., ge=0, le=1)
    highest_evidence_level: EvidenceLevel
    review_summary: str = Field(..., min_length=1)
    recommended_next_step: str | None = None


class AcceptanceReviewRead(AcceptanceReviewCreate):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class InternalLinkagePackCreate(BaseModel):
    candidate_id: int
    priority: Priority | None = None
    exact_search_terms_json: list[str] = Field(default_factory=list)
    fuzzy_search_terms_json: list[str] = Field(default_factory=list)
    transactional_search_suggestions_json: list[str] = Field(default_factory=list)
    extracted_signals_json: list[dict[str, Any]] = Field(default_factory=list)
    match_rationale: str | None = None


class InternalLinkagePackRead(BaseModel):
    id: int
    candidate_id: int
    priority: Priority
    exact_search_terms_json: list[str]
    fuzzy_search_terms_json: list[str]
    transactional_search_suggestions_json: list[str]
    extracted_signals_json: list[dict[str, Any]]
    match_rationale: str | None = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class InternalMatchRequest(BaseModel):
    linkage_pack_id: int
    extracted_signals_json: list[dict[str, Any]] = Field(default_factory=list)


class InternalMatchResultRead(BaseModel):
    id: int
    linkage_pack_id: int
    match_status: MatchStatus
    masked_internal_reference: str | None = None
    match_score: float
    matched_on_json: list[str]
    masked_profile_json: dict[str, Any]
    recommended_action: str | None = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ReportCreate(BaseModel):
    run_id: int
    report_type: ReportType
    title: str | None = None
    summary_json: dict[str, Any] | None = None


class ReportRead(BaseModel):
    id: int
    run_id: int
    report_type: ReportType
    title: str
    summary_json: dict[str, Any]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
