def test_report_creation_and_internal_match_stub(client, headers, create_candidate):
    candidate = create_candidate()

    client.post(
        "/acceptance-reviews",
        headers=headers,
        json={
            "candidate_id": candidate["id"],
            "amex_acceptance_score": 0.75,
            "highest_evidence_level": "L1",
            "review_summary": "Fake passive evidence only.",
            "recommended_next_step": "Prepare linkage pack.",
        },
    )

    pack_response = client.post(
        "/linkage-packs",
        headers=headers,
        json={
            "candidate_id": candidate["id"],
            "exact_search_terms_json": ["example-bet.test", "support@example-bet.test"],
            "fuzzy_search_terms_json": ["Example Bet", "ExampleBet"],
            "transactional_search_suggestions_json": ["MCC mismatch", "aggregator/sub-merchant route"],
            "extracted_signals_json": [
                {"signal_type": "domain", "signal_value": "example-bet.test"},
                {"signal_type": "email", "signal_value": "support@example-bet.test"},
                {"signal_type": "phone", "signal_value": "9990001111"},
            ],
            "match_rationale": "Fake local handoff package.",
        },
    )
    assert pack_response.status_code == 201, pack_response.text
    pack = pack_response.json()
    assert pack["priority"] == "P1"

    match_response = client.post(
        "/internal-match",
        headers=headers,
        json={
            "linkage_pack_id": pack["id"],
            "extracted_signals_json": [
                {"signal_type": "domain", "signal_value": "example-bet.test"},
                {"signal_type": "email", "signal_value": "support@example-bet.test"},
                {"signal_type": "phone", "signal_value": "9990001111"},
            ],
        },
    )
    assert match_response.status_code == 201, match_response.text
    match = match_response.json()
    assert match["match_status"] == "strong_match_found"
    assert match["masked_internal_reference"].startswith("AMEX-MERCH-***")
    assert "Stub result only" in match["recommended_action"]

    report_response = client.post(
        "/reports",
        headers=headers,
        json={
            "run_id": candidate["run_id"],
            "report_type": "monthly_summary",
            "title": "Fake Monthly Summary",
        },
    )
    assert report_response.status_code == 201, report_response.text
    report = report_response.json()
    assert report["summary_json"]["counts"]["candidates"] == 1
    assert report["summary_json"]["policy_reminder"].startswith("This report stores analyst/GPT-supplied observations only")
