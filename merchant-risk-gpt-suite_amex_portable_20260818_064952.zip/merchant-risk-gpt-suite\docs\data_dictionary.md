# Data Dictionary

## Run

Monthly, quarterly, baseline, or ad hoc monitoring batch.

- `run_month`: `YYYY-MM`
- `run_type`: `baseline`, `monthly_incremental`, `ad_hoc`, `quarterly_refresh`
- `status`: `draft`, `in_progress`, `review`, `completed`, `archived`

## Candidate

External public website, app, or business footprint supplied by a GPT/analyst.

- `canonical_domain`: normalized domain for comparison.
- `candidate_url`: stored URL string only. The backend does not fetch it.
- `suspected_category`: prohibited or high-risk category.
- `activity_confidence`: GPT/analyst supplied value from 0 to 1.
- `activity_risk_level`: analyst/GPT label such as low, medium, high, critical.
- `status`: `new`, `changed`, `unchanged`, `reopened`, `offline`, `false_positive`, `escalated`

## ExtractedSignal

Identity or linkage clue extracted from public observations.

Types: `domain`, `url`, `business_name`, `legal_name`, `phone`, `email`, `address`, `gstin`, `cin`, `pan`, `app_name`, `app_developer`, `social_handle`, `payment_gateway_clue`, `descriptor`, `other`.

## Evidence

Passive observation supplied by GPT/analyst.

Types: `page_text_summary`, `search_result_summary`, `screenshot_reference`, `payment_page_text`, `amex_logo`, `amex_text`, `card_network_list`, `checkout_observation`, `other`.

Levels: `none`, `L0`, `L1`, `L2`, `L3`, `L4`.

## AcceptanceReview

Analyst/GPT assessment of visible AmEx acceptance evidence.

- `amex_acceptance_score`: 0 to 1.
- `highest_evidence_level`: highest evidence level observed.

## InternalLinkagePack

Handoff package for approved internal search.

- `priority`: `P1`, `P2`, `P3`, `P4`
- `exact_search_terms_json`: exact terms such as domain, email, phone, GSTIN, CIN, PAN, legal name.
- `fuzzy_search_terms_json`: business name variants, DBA variants, descriptor variants.
- `transactional_search_suggestions_json`: patterns for approved internal analytics.

## InternalMatchResult

Fake local stub result or future approved internal match result.

Statuses: `not_checked`, `no_match`, `possible_match_found`, `strong_match_found`, `error`.

## Report

Stored JSON report for discovery, acceptance, or monthly summary workflows.
