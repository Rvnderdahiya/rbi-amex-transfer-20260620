from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services.dedupe import compare_candidate


router = APIRouter(tags=["candidates"])


@router.post("/candidates/compare", response_model=schemas.CandidateCompareResponse)
def compare_candidate_record(payload: schemas.CandidateCompareRequest, db: Session = Depends(get_db)) -> schemas.CandidateCompareResponse:
    return compare_candidate(db, payload)


@router.post("/candidates", response_model=schemas.CandidateRead, status_code=status.HTTP_201_CREATED)
def create_candidate(payload: schemas.CandidateCreate, db: Session = Depends(get_db)) -> models.Candidate:
    if not db.get(models.Run, payload.run_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")

    candidate_data = payload.model_dump(exclude={"signals"})
    candidate = models.Candidate(**candidate_data)
    db.add(candidate)
    db.flush()
    for signal in payload.signals:
        db.add(models.ExtractedSignal(candidate_id=candidate.id, **signal.model_dump()))
    db.commit()
    db.refresh(candidate)
    return candidate


@router.get("/candidates", response_model=list[schemas.CandidateRead])
def list_candidates(
    run_id: int | None = None,
    status_value: models.CandidateStatus | None = Query(default=None, alias="status"),
    needs_acceptance_review: bool = False,
    db: Session = Depends(get_db),
) -> list[models.Candidate]:
    query = db.query(models.Candidate)
    if run_id is not None:
        query = query.filter(models.Candidate.run_id == run_id)
    if status_value is not None:
        query = query.filter(models.Candidate.status == status_value)
    if needs_acceptance_review:
        reviewed_candidate_ids = select(models.AcceptanceReview.candidate_id)
        query = query.filter(~models.Candidate.id.in_(reviewed_candidate_ids))
    return query.order_by(models.Candidate.created_at.desc()).all()


@router.get("/candidates/{candidate_id}", response_model=schemas.CandidateRead)
def get_candidate(candidate_id: int, db: Session = Depends(get_db)) -> models.Candidate:
    candidate = db.get(models.Candidate, candidate_id)
    if not candidate:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    return candidate


@router.patch("/candidates/{candidate_id}", response_model=schemas.CandidateRead)
def update_candidate(candidate_id: int, payload: schemas.CandidateUpdate, db: Session = Depends(get_db)) -> models.Candidate:
    candidate = db.get(models.Candidate, candidate_id)
    if not candidate:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(candidate, field, value)
    db.commit()
    db.refresh(candidate)
    return candidate


@router.post("/candidates/{candidate_id}/signals", response_model=list[schemas.ExtractedSignalRead], status_code=status.HTTP_201_CREATED)
def add_candidate_signals(candidate_id: int, payload: schemas.SignalBulkCreate, db: Session = Depends(get_db)) -> list[models.ExtractedSignal]:
    if not db.get(models.Candidate, candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    created: list[models.ExtractedSignal] = []
    for signal in payload.signals:
        record = models.ExtractedSignal(candidate_id=candidate_id, **signal.model_dump())
        db.add(record)
        created.append(record)
    db.commit()
    for record in created:
        db.refresh(record)
    return created


@router.get("/candidates/{candidate_id}/signals", response_model=list[schemas.ExtractedSignalRead])
def get_candidate_signals(candidate_id: int, db: Session = Depends(get_db)) -> list[models.ExtractedSignal]:
    if not db.get(models.Candidate, candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    return (
        db.query(models.ExtractedSignal)
        .filter(models.ExtractedSignal.candidate_id == candidate_id)
        .order_by(models.ExtractedSignal.created_at.asc())
        .all()
    )
