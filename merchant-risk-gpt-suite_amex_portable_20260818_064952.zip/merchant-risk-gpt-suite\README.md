# Merchant Risk GPT Suite

Local prototype for two Custom GPTs and supporting APIs for an American Express merchant prohibited-activity monitoring workflow.

## 1. Problem Statement

Compliance analysts need a controlled way to record suspicious external websites, apps, or public businesses connected to prohibited or high-risk activity, assess whether American Express appears to be accepted, and prepare a handoff package that helps approved internal AmEx teams search for disguised merchant relationships.

## 2. What This Project Does

- Provides a FastAPI backend for runs, candidates, extracted signals, evidence, acceptance reviews, linkage packs, JSON exports, and reports.
- Provides deterministic candidate comparison and deduplication.
- Provides a fake internal matching stub using sample masked data only.
- Provides instruction files and Action OpenAPI specs for two manually configured Custom GPTs:
  - Merchant Risk Discovery GPT
  - AmEx Acceptance & Linkage GPT

## 3. What This Project Explicitly Does Not Do

- It does not crawl, scrape, browse, fetch, or retrieve public websites.
- It does not use Playwright, Selenium, Scrapy, Requests-based crawlers, browser automation, or automated checkout.
- It does not perform purchases, test authorizations, or live transactions.
- It does not connect to real AmEx systems.
- It does not store cardholder data or full payment card numbers.
- It does not use real suspicious merchant data.

External discovery must happen only through the Custom GPT's built-in web search or browsing capability. Backend Actions only store, compare, deduplicate, score, report, export, and optionally run the fake internal match stub.

## 4. Local Setup

```powershell
cd C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` if needed. Keep `APP_API_KEY` private for any shared environment.

## 5. Run With Docker

```powershell
cd C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite
Copy-Item .env.example .env
docker compose up --build
```

The API listens on `http://localhost:8000`.

## 6. Run Backend Locally

```powershell
cd C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite
.\.venv\Scripts\Activate.ps1
$env:PYTHONPATH = "$PWD\backend"
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Health check:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
```

Protected endpoints require:

```text
X-API-Key: change-me
```

## 7. Run Tests

```powershell
cd C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite
.\.venv\Scripts\Activate.ps1
$env:PYTHONPATH = "$PWD\backend"
pytest
```

## 8. Configure The Two Custom GPTs Manually

The exact GPT Builder UI may vary by workspace and plan. Use these file-based steps:

1. Open ChatGPT.
2. Go to GPTs.
3. Create a new GPT.
4. Name it `Merchant Risk Discovery GPT`.
5. Paste `gpts/merchant-risk-discovery-gpt/instructions.md` into Instructions.
6. Enable web search/browsing capability.
7. Add an Action using `gpts/merchant-risk-discovery-gpt/action_openapi.yaml`.
8. Configure authentication using the `X-API-Key` header.
9. Use the local backend public URL during development. If running locally, expose `http://localhost:8000` through an approved local tunnel only for development.
10. Test using `gpts/merchant-risk-discovery-gpt/conversation_starters.md`.
11. Repeat for `AmEx Acceptance & Linkage GPT` with `gpts/amex-acceptance-linkage-gpt/instructions.md` and `gpts/amex-acceptance-linkage-gpt/action_openapi.yaml`.
12. In the AmEx environment, replace the local backend URL with the approved internal API URL.

## 9. Paste Action OpenAPI Schemas Into GPT Builder

Each Action schema is intentionally narrow:

- Discovery GPT Action: create/list runs, compare candidates, create candidates, add signals, create discovery reports, export runs.
- Acceptance GPT Action: list candidates pending review, get a candidate, store evidence, create acceptance review, create linkage pack, call fake internal match stub, create acceptance report.

The schemas do not define any URL fetching, crawling, scraping, or browser automation operation.

## 10. Migrate To AmEx Machine

See `MIGRATION_TO_AMEX.md`. At minimum:

- Move only fake/sample data unless AmEx approves otherwise.
- Replace SQLite with an AmEx-approved database.
- Replace the fake internal match stub with an approved internal API.
- Move secrets to the enterprise secrets manager.
- Add TLS, network allowlisting, audit logs, monitoring, RBAC, and deployment controls.
- Complete InfoSec, Legal, Compliance, Privacy, and Architecture reviews.
