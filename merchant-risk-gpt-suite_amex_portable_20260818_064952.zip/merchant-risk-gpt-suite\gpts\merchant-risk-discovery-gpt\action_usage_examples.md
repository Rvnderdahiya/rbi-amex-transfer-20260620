# Action Usage Examples

## Create A Run

Use `createRun` when starting a new monitoring batch.

```json
{
  "run_month": "2026-08",
  "run_type": "monthly_incremental",
  "region": "India",
  "created_by": "analyst@example.test",
  "notes": "Local prototype run with fake/sample data only.",
  "status": "in_progress"
}
```

## Compare Before Creating Candidate

Use `compareCandidate` before saving a new candidate.

```json
{
  "canonical_domain": "example-bet.test",
  "candidate_url": "https://example-bet.test/payments",
  "business_name_detected": "Example Bet",
  "signals": [
    {
      "signal_type": "domain",
      "signal_value": "example-bet.test",
      "confidence": 1,
      "source_note": "Visible public domain supplied by GPT browsing."
    }
  ]
}
```

## Create Candidate

Use `createCandidate` only after comparison.

```json
{
  "run_id": 1,
  "canonical_domain": "example-bet.test",
  "candidate_url": "https://example-bet.test",
  "business_name_detected": "Example Bet",
  "suspected_category": "online betting/gambling",
  "activity_confidence": 0.86,
  "activity_risk_level": "high",
  "status": "new",
  "first_seen": "2026-08-17",
  "last_seen": "2026-08-17",
  "source_summary": "GPT-observed public page summaries only.",
  "gpt_discovery_notes": "No backend crawling performed.",
  "signals": []
}
```

## Add Signals

Use `addCandidateSignals` to store extracted identity clues.

```json
{
  "signals": [
    {
      "signal_type": "email",
      "signal_value": "support@example-bet.test",
      "confidence": 0.8,
      "source_note": "Visible on public contact page during GPT browsing."
    }
  ]
}
```
