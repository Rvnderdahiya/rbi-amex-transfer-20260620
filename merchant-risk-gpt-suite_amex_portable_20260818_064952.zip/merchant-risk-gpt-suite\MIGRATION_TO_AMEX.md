# Migration To AmEx

## Migration Goal

Move the prototype into an approved American Express environment without changing the core separation of responsibilities:

- GPTs may perform public discovery only through built-in web search/browsing.
- Backend APIs may store, compare, deduplicate, report, export, and match only through approved internal services.
- Backend APIs must not crawl, scrape, or fetch public websites.

## Required Changes

1. Replace SQLite with an AmEx-approved database.
2. Add managed schema migrations.
3. Replace the fake internal match stub with an approved internal merchant/entity matching API.
4. Move `APP_API_KEY` and all secrets to the enterprise secrets manager.
5. Put the API behind TLS, SSO or service authentication, and network allowlisting.
6. Add RBAC for analyst, reviewer, admin, and audit roles.
7. Add structured audit logs for create/update/report/export actions.
8. Add retention policies for evidence, candidate records, and reports.
9. Add monitoring, alerts, backup, restore, and disaster recovery procedures.
10. Complete InfoSec, Legal, Compliance, Privacy, and Architecture reviews.

## GPT Builder Changes

In GPT Builder, replace the local development server URL in each Action schema with the approved internal API URL. Keep the same narrow Action surface unless Architecture and Compliance approve additional operations.

## Data Migration

Do not migrate local prototype data into AmEx systems unless explicitly approved. Treat local sample records as fake demonstration data.
