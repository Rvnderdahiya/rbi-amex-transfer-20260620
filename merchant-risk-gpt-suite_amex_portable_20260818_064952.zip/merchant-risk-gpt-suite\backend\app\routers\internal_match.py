from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services.internal_match_stub import fake_internal_match
from app.services.scoring import derive_priority


router = APIRouter(tags=["internal-linkage"])


@router.post("/linkage-packs", response_model=schemas.InternalLinkagePackRead, status_code=status.HTTP_201_CREATED)
def create_linkage_pack(payload: schemas.InternalLinkagePackCreate, db: Session = Depends(get_db)) -> models.InternalLinkagePack:
    candidate = db.get(models.Candidate, payload.candidate_id)
    if not candidate:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")

    priority = payload.priority
    if priority is None:
        latest_review = (
            db.query(models.AcceptanceReview)
            .filter(models.AcceptanceReview.candidate_id == candidate.id)
            .order_by(models.AcceptanceReview.created_at.desc())
            .first()
        )
        acceptance_score = latest_review.amex_acceptance_score if latest_review else 0.0
        priority = derive_priority(candidate.activity_confidence, acceptance_score, candidate.status)

    data = payload.model_dump()
    data["priority"] = priority
    pack = models.InternalLinkagePack(**data)
    db.add(pack)
    db.commit()
    db.refresh(pack)
    return pack


@router.get("/candidates/{candidate_id}/linkage-pack", response_model=schemas.InternalLinkagePackRead)
def get_latest_linkage_pack(candidate_id: int, db: Session = Depends(get_db)) -> models.InternalLinkagePack:
    if not db.get(models.Candidate, candidate_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found.")
    pack = (
        db.query(models.InternalLinkagePack)
        .filter(models.InternalLinkagePack.candidate_id == candidate_id)
        .order_by(models.InternalLinkagePack.created_at.desc())
        .first()
    )
    if not pack:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Linkage pack not found.")
    return pack


@router.post("/internal-match", response_model=schemas.InternalMatchResultRead, status_code=status.HTTP_201_CREATED)
def internal_match_stub(payload: schemas.InternalMatchRequest, db: Session = Depends(get_db)) -> models.InternalMatchResult:
    pack = db.get(models.InternalLinkagePack, payload.linkage_pack_id)
    if not pack:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Linkage pack not found.")

    signals = payload.extracted_signals_json or pack.extracted_signals_json
    result_data = fake_internal_match(signals)
    result = models.InternalMatchResult(linkage_pack_id=pack.id, **result_data)
    db.add(result)
    db.commit()
    db.refresh(result)
    return result
