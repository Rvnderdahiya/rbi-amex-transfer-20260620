def test_candidate_creation_and_retrieval(client, headers, create_candidate):
    candidate = create_candidate()

    response = client.get(f"/candidates/{candidate['id']}", headers=headers)

    assert response.status_code == 200
    body = response.json()
    assert body["canonical_domain"] == "example-bet.test"
    assert body["candidate_url"] == "https://example-bet.test/"
    assert body["suspected_category"] == "online betting/gambling"


def test_candidate_requires_api_key(client, create_run):
    run = create_run()

    response = client.post(
        "/candidates",
        json={
            "run_id": run["id"],
            "canonical_domain": "example-bet.test",
            "candidate_url": "https://example-bet.test",
            "suspected_category": "online betting/gambling",
            "activity_confidence": 0.8,
            "activity_risk_level": "high",
        },
    )

    assert response.status_code == 401
