from __future__ import annotations

from app.models import MatchStatus
from app.services.validation import normalize_signal


FAKE_INTERNAL_PROFILES = [
    {
        "masked_internal_reference": "AMEX-MERCH-***-1042",
        "profile": {
            "legal_name": "Example Digital Entertainment Pvt Ltd",
            "descriptor": "EXAMPLE*DIGITAL",
            "region": "IN",
            "mcc_hint": "Digital services",
            "domain": "example-bet.test",
            "phone": "9990001111",
        },
    },
    {
        "masked_internal_reference": "AMEX-MERCH-***-2088",
        "profile": {
            "legal_name": "Example Wellness Marketplace LLC",
            "descriptor": "EXAMPLE*WELLNESS",
            "region": "US",
            "mcc_hint": "Health products",
            "domain": "example-pharma.test",
            "email": "support@example-pharma.test",
        },
    },
    {
        "masked_internal_reference": "AMEX-MERCH-***-3135",
        "profile": {
            "legal_name": "Example Luxury Outlet Inc",
            "descriptor": "EXAMPLE*OUTLET",
            "region": "US",
            "mcc_hint": "Retail",
            "domain": "example-counterfeit.test",
        },
    },
]


def _flatten_input_signals(signals: list[dict]) -> dict[str, set[str]]:
    flattened: dict[str, set[str]] = {}
    for signal in signals:
        signal_type = str(signal.get("signal_type") or signal.get("type") or "").strip()
        signal_value = str(signal.get("signal_value") or signal.get("value") or "").strip()
        if not signal_type or not signal_value:
            continue
        normalized = normalize_signal(signal_type, signal_value)
        if normalized:
            flattened.setdefault(signal_type, set()).add(normalized)
    return flattened


def fake_internal_match(signals: list[dict]) -> dict:
    incoming = _flatten_input_signals(signals)
    best: tuple[float, dict | None, list[str]] = (0.0, None, [])

    for sample in FAKE_INTERNAL_PROFILES:
        matched_on: list[str] = []
        profile = sample["profile"]
        score = 0.0
        for key in ["domain", "email", "phone", "descriptor", "legal_name"]:
            if not profile.get(key):
                continue
            normalized_profile_value = normalize_signal(key if key != "legal_name" else "legal_name", profile[key])
            if normalized_profile_value in incoming.get(key, set()):
                score += 0.35 if key in {"domain", "email", "phone"} else 0.20
                matched_on.append(key)
        if score > best[0]:
            best = (min(score, 0.95), sample, matched_on)

    score, sample, matched_on = best
    if not sample:
        return {
            "match_status": MatchStatus.no_match,
            "masked_internal_reference": None,
            "match_score": 0.0,
            "matched_on_json": [],
            "masked_profile_json": {},
            "recommended_action": "No fake stub match found. Route to approved internal lookup when available.",
        }

    status = MatchStatus.strong_match_found if score >= 0.70 else MatchStatus.possible_match_found
    masked_profile = {
        "legal_name_hint": _mask_text(sample["profile"].get("legal_name", "")),
        "descriptor_hint": sample["profile"].get("descriptor"),
        "region": sample["profile"].get("region"),
        "mcc_hint": sample["profile"].get("mcc_hint"),
    }
    return {
        "match_status": status,
        "masked_internal_reference": sample["masked_internal_reference"],
        "match_score": round(score, 2),
        "matched_on_json": matched_on,
        "masked_profile_json": masked_profile,
        "recommended_action": "Stub result only. Validate using an approved AmEx internal matching service before action.",
    }


def _mask_text(value: str) -> str:
    words = value.split()
    if not words:
        return ""
    return " ".join(f"{word[:2]}***" if len(word) > 2 else "***" for word in words)
