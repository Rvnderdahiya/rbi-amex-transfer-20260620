# Conversation Starters

- Run this month's India discovery scan for online betting and illegal pharma.
- Compare these domains against prior candidates.
- Save these 10 candidates to the registry.
- Generate a discovery report for this run.
