# Porting Readiness

## Local Validation Date/Time

2026-08-17T18:11:06.1960120+05:30

## Machine And Environment Details

- Working directory: `C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite`
- OS/platform: Windows-10-10.0.26200-SP0
- Machine architecture: AMD64
- Processor: Intel64 Family 6 Model 140 Stepping 1, GenuineIntel
- Python: 3.11.9
- Backend framework: FastAPI
- Local database: SQLite at `merchant_risk.db`
- API base URL used for validation: `http://127.0.0.1:8000`
- API key header used for local validation: `X-API-Key: change-me`

## Commands Run

```powershell
cd C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (!(Test-Path .env)) { Copy-Item .env.example .env }
$env:PYTHONPATH = "$PWD\backend"
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
Invoke-RestMethod http://127.0.0.1:8000/health
```

The live workflow validation used PowerShell `Invoke-RestMethod` calls to:

- Create a run from `backend/app/seed/sample_run.json`.
- Compare each fake sample candidate before creating it.
- Create 4 fake sample candidates from `backend/app/seed/sample_candidates.json`.
- Retrieve candidates pending acceptance review.
- Store manually supplied passive AmEx acceptance evidence.
- Create 4 acceptance reviews.
- Create 2 internal linkage packs.
- Call the fake internal match stub.
- Generate discovery, acceptance, and monthly summary reports.
- Export the run as JSON.

The final automated test evidence was saved with:

```powershell
$env:PYTHONPATH = "$PWD\backend"
.\.venv\Scripts\python.exe -m pytest 2>&1 | Tee-Object -FilePath validation_outputs\pytest_output.txt
```

The Action spec, instruction, live OpenAPI, and no-crawling validation was run with local Python and PyYAML against local files and `http://127.0.0.1:8000/openapi.json`. No public websites were contacted.

## Test Results

- Automated tests: passed.
- Test count: 6 passed.
- Warning observed: Starlette/FastAPI TestClient emits a deprecation warning about `httpx` test-client internals. This does not affect runtime backend behavior. The backend runtime modules do not import `httpx`.
- Health check: passed.
- Sample data load: passed.
- Discovery GPT flow simulation: passed.
- Acceptance & Linkage GPT flow simulation: passed.
- Report generation: passed.
- OpenAPI Action YAML load check: passed.
- GPT instruction completeness check: passed.
- No-crawling static backend scan: passed.
- Live backend endpoint surface check: passed.

## API Endpoints Validated

- `GET /health`
- `POST /runs`
- `GET /runs`
- `GET /runs/{run_id}`
- `PATCH /runs/{run_id}`
- `POST /candidates`
- `GET /candidates`
- `GET /candidates/{candidate_id}`
- `PATCH /candidates/{candidate_id}`
- `POST /candidates/compare`
- `POST /candidates/{candidate_id}/signals`
- `GET /candidates/{candidate_id}/signals`
- `POST /evidence`
- `GET /candidates/{candidate_id}/evidence`
- `POST /acceptance-reviews`
- `GET /candidates/{candidate_id}/acceptance-review`
- `POST /linkage-packs`
- `GET /candidates/{candidate_id}/linkage-pack`
- `POST /internal-match`
- `POST /reports`
- `GET /reports/{report_id}`
- `GET /runs/{run_id}/reports`
- `POST /exports/run/{run_id}`

## Output Files

Validation output files are in `validation_outputs/`:

- `health.json`
- `sample_run_created.json`
- `discovery_comparisons.json`
- `loaded_candidates.json`
- `pending_acceptance_candidates.json`
- `evidence_reviews.json`
- `linkage_and_stub_results.json`
- `monthly_discovery_report.json`
- `amex_acceptance_linkage_report.json`
- `monthly_summary_report.json`
- `endpoint_validation.json`
- `run_export.json`
- `spec_instruction_api_validation.json`
- `pytest_output.txt`

## No-Crawling Validation

The runtime backend modules were scanned for:

- `requests`
- `httpx`
- `playwright`
- `selenium`
- `scrapy`
- `urllib.request`
- `urlopen`
- `webdriver`
- `sync_playwright`
- `async_playwright`

Result: no hits in backend runtime modules.

The backend may store URL strings as references, but it does not dereference them.

## Known Limitations

- This is a local prototype, not production software.
- SQLite is for local development only.
- There is no RBAC, SSO, enterprise audit log, or production monitoring.
- The internal match endpoint is a fake masked stub and does not connect to AmEx.
- No real AmEx data, cardholder data, full payment card numbers, or real suspicious merchant data should be used locally.
- L3 controlled authorization is not implemented.
- L4 internal auth/clearing evidence is not implemented and belongs inside approved AmEx systems.
- The request mentioned a "GPT-3 flow"; this project defines two Custom GPTs, so validation treats that as the AmEx Acceptance & Linkage GPT flow.

## Porting Checklist

- Review with InfoSec.
- Review with Legal.
- Review with Compliance.
- Review with Privacy.
- Review with Architecture.
- Replace SQLite with an AmEx-approved database.
- Add managed database migrations.
- Replace the fake internal match stub with an approved internal API.
- Move secrets to the enterprise secrets manager.
- Replace local API key auth with approved enterprise authentication.
- Add RBAC for analyst, reviewer, admin, and audit roles.
- Add structured audit logs.
- Add monitoring, alerting, backup, restore, and disaster recovery.
- Use TLS and network allowlisting.
- Define evidence artifact storage and retention.
- Confirm any use of public business PAN signals is policy-approved and masked in non-secure environments.
- Keep the no-crawling policy in force for backend APIs.

## AmEx Environment Assumptions

- The deployment environment can host a FastAPI-compatible Python service.
- An approved database platform is available.
- An approved internal merchant/entity matching API can replace the stub.
- Enterprise secrets management is available.
- Network controls can restrict GPT Action traffic to the approved backend.
- Internal teams will decide whether and how to store evidence artifacts.
- Any controlled test authorization protocol, if ever approved, will be implemented outside this prototype.

## Final Readiness Decision

Ready to port to an approved AmEx development environment for formal review and hardening.

Not ready for production use until the migration checklist is completed and InfoSec, Legal, Compliance, Privacy, and Architecture approvals are obtained.
