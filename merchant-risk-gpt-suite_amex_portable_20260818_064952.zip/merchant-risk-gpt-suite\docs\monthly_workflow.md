# Monthly Workflow

1. Create a `monthly_incremental` run for the month and region.
2. Use Merchant Risk Discovery GPT to search public sources through built-in web search/browsing only.
3. For each finding, extract visible signals and source summaries.
4. Call candidate comparison before saving any new candidate.
5. Save new or changed candidate records and extracted signals.
6. Generate a discovery report.
7. Use AmEx Acceptance & Linkage GPT to review candidates pending acceptance review.
8. Store passive AmEx acceptance evidence and create acceptance reviews.
9. Create internal linkage packs for candidates with possible AmEx acceptance.
10. Use the fake internal match stub only for local prototype demonstration.
11. Generate acceptance and monthly summary reports.
12. Export the run JSON for review.

No step allows the backend to crawl, scrape, fetch, or automate public websites.
