# Evidence Levels

## L0: AmEx Logo Visible, Weak

American Express logo appears on a public page, footer, payment icon strip, or screenshot. This is weak evidence because logos may be stale, generic, or inaccurate.

## L1: Payment Page Or FAQ Says American Express Accepted

A public payment page, FAQ, support page, checkout text, or merchant help page says American Express or AmEx is accepted. No transaction is performed.

## L2: Passive Technical Checkout Evidence

Passive technical evidence such as a public checkout card network list or AmEx BIN/card-type acceptance observed by GPT browsing, with no transaction and no purchase.

## L3: Controlled Test Authorization

Controlled test authorization. Not implemented here. Requires Legal/Compliance approval, formal protocol, and approved AmEx systems.

## L4: Internal AmEx Auth/Clearing Evidence

Internal AmEx authorization or clearing evidence. Not implemented here. Belongs inside approved AmEx systems and must not be handled by the external GPT phase.
