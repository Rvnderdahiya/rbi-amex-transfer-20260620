from __future__ import annotations

from collections import Counter
from datetime import date, datetime
from typing import Any

from sqlalchemy.orm import Session

from app import models


def _jsonable(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if hasattr(value, "value"):
        return value.value
    return value


def _model_dict(obj: Any, fields: list[str]) -> dict[str, Any]:
    return {field: _jsonable(getattr(obj, field)) for field in fields}


def build_report_summary(db: Session, run_id: int, report_type: models.ReportType) -> dict[str, Any]:
    run = db.get(models.Run, run_id)
    if not run:
        raise ValueError(f"Run {run_id} not found.")

    candidates = db.query(models.Candidate).filter(models.Candidate.run_id == run_id).all()
    candidate_ids = [candidate.id for candidate in candidates]
    evidence = db.query(models.Evidence).filter(models.Evidence.candidate_id.in_(candidate_ids)).all() if candidate_ids else []
    reviews = db.query(models.AcceptanceReview).filter(models.AcceptanceReview.candidate_id.in_(candidate_ids)).all() if candidate_ids else []
    linkage_packs = db.query(models.InternalLinkagePack).filter(models.InternalLinkagePack.candidate_id.in_(candidate_ids)).all() if candidate_ids else []

    summary: dict[str, Any] = {
        "run": _model_dict(run, ["id", "run_month", "run_type", "region", "status", "created_by", "created_at"]),
        "counts": {
            "candidates": len(candidates),
            "evidence_items": len(evidence),
            "acceptance_reviews": len(reviews),
            "linkage_packs": len(linkage_packs),
        },
        "candidate_status_counts": dict(Counter(candidate.status.value for candidate in candidates)),
        "suspected_category_counts": dict(Counter(candidate.suspected_category for candidate in candidates)),
        "activity_risk_counts": dict(Counter(candidate.activity_risk_level for candidate in candidates)),
        "evidence_level_counts": dict(Counter(item.evidence_level.value for item in evidence)),
    }

    if report_type in {models.ReportType.discovery, models.ReportType.monthly_summary}:
        summary["discovery_candidates"] = [
            _model_dict(
                candidate,
                [
                    "id",
                    "canonical_domain",
                    "candidate_url",
                    "business_name_detected",
                    "suspected_category",
                    "activity_confidence",
                    "activity_risk_level",
                    "status",
                    "source_summary",
                ],
            )
            for candidate in candidates
        ]

    if report_type in {models.ReportType.acceptance, models.ReportType.monthly_summary}:
        latest_reviews = _latest_by_candidate(reviews)
        latest_packs = _latest_by_candidate(linkage_packs)
        summary["acceptance_handoff"] = []
        for candidate in candidates:
            review = latest_reviews.get(candidate.id)
            pack = latest_packs.get(candidate.id)
            summary["acceptance_handoff"].append(
                {
                    "candidate_id": candidate.id,
                    "domain": candidate.canonical_domain,
                    "business_name": candidate.business_name_detected,
                    "highest_evidence_level": review.highest_evidence_level.value if review else "none",
                    "amex_acceptance_score": review.amex_acceptance_score if review else None,
                    "recommended_next_step": review.recommended_next_step if review else "Acceptance review pending.",
                    "linkage_priority": pack.priority.value if pack else None,
                    "linkage_pack_id": pack.id if pack else None,
                }
            )

    summary["policy_reminder"] = (
        "This report stores analyst/GPT-supplied observations only. The backend does not crawl, scrape, "
        "browse, automate checkout, or retrieve public web pages."
    )
    return summary


def export_run(db: Session, run_id: int) -> dict[str, Any]:
    run = db.get(models.Run, run_id)
    if not run:
        raise ValueError(f"Run {run_id} not found.")

    candidates = db.query(models.Candidate).filter(models.Candidate.run_id == run_id).all()
    reports = db.query(models.Report).filter(models.Report.run_id == run_id).all()
    export = {
        "run": _model_dict(run, ["id", "run_month", "run_type", "region", "created_at", "created_by", "notes", "status"]),
        "candidates": [],
        "reports": [
            _model_dict(report, ["id", "run_id", "report_type", "title", "summary_json", "created_at"])
            for report in reports
        ],
        "policy_reminder": "Export contains stored records only and no crawled public web content.",
    }

    for candidate in candidates:
        export["candidates"].append(
            {
                **_model_dict(
                    candidate,
                    [
                        "id",
                        "run_id",
                        "canonical_domain",
                        "candidate_url",
                        "business_name_detected",
                        "suspected_category",
                        "activity_confidence",
                        "activity_risk_level",
                        "status",
                        "first_seen",
                        "last_seen",
                        "source_summary",
                        "gpt_discovery_notes",
                        "created_at",
                        "updated_at",
                    ],
                ),
                "signals": [
                    _model_dict(signal, ["id", "signal_type", "signal_value", "confidence", "source_note", "created_at"])
                    for signal in candidate.signals
                ],
                "evidence": [
                    _model_dict(item, ["id", "evidence_type", "evidence_level", "evidence_summary", "source_url", "artifact_reference", "observed_at", "created_at"])
                    for item in candidate.evidence
                ],
                "acceptance_reviews": [
                    _model_dict(review, ["id", "amex_acceptance_score", "highest_evidence_level", "review_summary", "recommended_next_step", "created_at"])
                    for review in candidate.acceptance_reviews
                ],
                "linkage_packs": [
                    _model_dict(pack, ["id", "priority", "exact_search_terms_json", "fuzzy_search_terms_json", "transactional_search_suggestions_json", "extracted_signals_json", "match_rationale", "created_at"])
                    for pack in candidate.linkage_packs
                ],
            }
        )
    return export


def _latest_by_candidate(items: list[Any]) -> dict[int, Any]:
    latest: dict[int, Any] = {}
    for item in sorted(items, key=lambda value: value.created_at):
        latest[item.candidate_id] = item
    return latest
