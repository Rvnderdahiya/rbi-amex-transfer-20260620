# Security And Compliance

## Prototype Status

This local project is a prototype. It is not production software and must not be used with real AmEx data on a personal laptop.

## Data Restrictions

- Use fake/sample data only in local development.
- Do not store cardholder data.
- Do not store full payment card numbers.
- Do not store PAN except a public business PAN signal field if policy allows.
- Mask public business PAN signals in non-secure environments unless explicit policy approval exists.
- Do not store authentication secrets in source control.

## Prohibited Technical Behavior

The backend must not:

- Crawl websites.
- Scrape websites.
- Fetch external URLs.
- Retrieve candidate web pages.
- Use browser automation.
- Use Playwright, Selenium, Scrapy, Requests-based crawlers, or any automated public web data collection.
- Automate checkout.
- Complete purchases.
- Perform live transaction testing.

External discovery must be done only through the Custom GPT's built-in web search/browsing capability. Backend Actions are limited to storing, comparing, deduplicating, scoring, reporting, exporting, and optional fake internal matching.

## Production Controls Required Before AmEx Migration

Before moving into an AmEx environment, review with:

- InfoSec
- Legal
- Compliance
- Privacy
- Architecture

Production implementation must:

- Replace SQLite with an AmEx-approved database.
- Replace the internal match stub with an approved internal API.
- Use an enterprise secrets manager.
- Enable logging, monitoring, audit trail, and RBAC.
- Use TLS and network allowlisting.
- Apply data retention and deletion controls.
- Define evidence handling rules and approved evidence artifact storage.
- Require approval for L3 controlled authorization workflows.
- Keep L4 internal auth/clearing evidence inside approved AmEx systems.
