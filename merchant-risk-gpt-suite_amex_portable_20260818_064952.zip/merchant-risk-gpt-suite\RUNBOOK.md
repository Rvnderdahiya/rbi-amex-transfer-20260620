# Runbook

## Start Locally

```powershell
cd C:\Users\QSS\Documents\Ravender\MONITORING_LATEST\Windfall_monitoring\merchant-risk-gpt-suite
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
$env:PYTHONPATH = "$PWD\backend"
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

## Health Check

```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
```

## API Key

Protected endpoints require:

```text
X-API-Key: change-me
```

Use a different value in `.env` outside quick local testing.

## Manual Custom GPT Setup

The exact GPT Builder UI may vary by workspace and plan. Use these conceptual, file-based steps:

1. Open ChatGPT.
2. Go to GPTs.
3. Create a new GPT.
4. Name it `Merchant Risk Discovery GPT`.
5. Paste `gpts/merchant-risk-discovery-gpt/instructions.md` into Instructions.
6. Enable web search/browsing capability.
7. Add Action using `gpts/merchant-risk-discovery-gpt/action_openapi.yaml`.
8. Configure authentication using `X-API-Key`.
9. Use the local backend public URL during development.
10. Test using conversation starters.
11. Repeat for `AmEx Acceptance & Linkage GPT` with its own instruction and OpenAPI files.
12. In the AmEx environment, replace the local backend URL with the approved internal API URL.

## Monthly Operating Flow

1. Create a run for the month.
2. Ask Merchant Risk Discovery GPT to perform GPT-led discovery.
3. Compare each candidate before creating it.
4. Save candidate records and extracted signals.
5. Ask AmEx Acceptance & Linkage GPT to review pending candidates.
6. Store passive AmEx acceptance evidence.
7. Create acceptance reviews and linkage packs.
8. Optionally call the fake internal match stub in local demo only.
9. Generate discovery, acceptance, and monthly summary reports.
10. Export the run JSON for handoff or review.

## Incident Handling

If any code or process is found to retrieve public web pages automatically, stop use of the prototype, remove the behavior, and re-run the validation checklist in `PORTING_READINESS.md`.
