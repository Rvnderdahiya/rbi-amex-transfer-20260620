# Analyst Review Workflow

## Discovery Review

Analysts should verify that each candidate is evidence-backed and described as suspected activity, not as a final legal conclusion.

Required review points:

- Candidate domain and URL are visible public identifiers.
- Category assignment is supported by observed public signals.
- Confidence score is reasonable and not overstated.
- Source summary identifies what was observed without copying excessive copyrighted text.
- Candidate was compared against the registry before creation.

## Acceptance Review

Analysts should confirm that evidence is passive unless an approved protocol exists.

Required review points:

- No purchase or live transaction was attempted.
- No automated checkout or browser automation was used by the backend.
- Evidence level follows `docs/evidence_levels.md`.
- Source URL is stored only as a reference and is not fetched by the backend.
- Linkage pack includes exact and fuzzy search terms for approved internal review.

## Handoff Review

Never claim an internal merchant match unless an approved internal API returns one. The local stub returns masked fake results only.
