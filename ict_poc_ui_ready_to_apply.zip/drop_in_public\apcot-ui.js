// Single Chainlit custom_js entry point for the APCOT Review Search UI.
// Drop this file into: agent_api/public/apcot-ui.js
// It loads the richer UI scripts without touching Python, LangGraph, SQL, or LLM logic.

(function () {
  const ASSETS = [
    "/public/title-bar.js",
    "/public/theme-toggle.js"
  ];

  ASSETS.forEach((src) => {
    if (document.querySelector(`script[data-apcot-ui-src="${src}"]`)) return;

    const script = document.createElement("script");
    script.src = `${src}?v=20260629`;
    script.defer = true;
    script.setAttribute("data-apcot-ui-src", src);
    document.head.appendChild(script);
  });
})();
