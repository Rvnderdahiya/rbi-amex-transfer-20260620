param(
  [string]$AgentRoot = "."
)

$ErrorActionPreference = "Stop"

function Write-Step {
  param([string]$Message)
  Write-Host ""
  Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Good {
  param([string]$Message)
  Write-Host "OK  $Message" -ForegroundColor Green
}

function Write-Utf8NoBomLines {
  param(
    [string]$Path,
    [string[]]$Lines
  )

  $encoding = New-Object System.Text.UTF8Encoding -ArgumentList $false
  [System.IO.File]::WriteAllLines($Path, $Lines, $encoding)
}

function Clean-TomlLine {
  param([string]$Line)

  if ($null -eq $Line) {
    return ""
  }

  return $Line.Replace([string][char]0xFEFF, "").Replace("ï»¿", "").Replace("Ã¯Â»Â¿", "").TrimEnd()
}

function Set-ChainlitUiAssetConfig {
  param([string]$ConfigPath)

  $ConfigDir = Split-Path -Parent $ConfigPath
  New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null

  $CssLine = 'custom_css = "/public/custom.css"'
  $JsLine = 'custom_js = "/public/apcot-ui.js"'

  if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    Write-Utf8NoBomLines -Path $ConfigPath -Lines @("[UI]", $CssLine, $JsLine)
    return
  }

  $OriginalLines = @(Get-Content -LiteralPath $ConfigPath | ForEach-Object { Clean-TomlLine -Line $_ })
  $OriginalLines = @($OriginalLines | Where-Object {
    $_ -notmatch '^\s*#?\s*custom_css\s*=' -and $_ -notmatch '^\s*#?\s*custom_js\s*='
  })

  $UiStart = -1
  for ($i = 0; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[UI\]\s*$') {
      $UiStart = $i
      break
    }
  }

  if ($UiStart -lt 0) {
    Write-Utf8NoBomLines -Path $ConfigPath -Lines @($OriginalLines + "" + "[UI]" + $CssLine + $JsLine)
    return
  }

  $UiEnd = $OriginalLines.Count
  for ($i = $UiStart + 1; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[[^\]]+\]\s*$') {
      $UiEnd = $i
      break
    }
  }

  $Before = @($OriginalLines[0..$UiStart])
  $Body = @()
  if (($UiStart + 1) -le ($UiEnd - 1)) {
    $Body = @($OriginalLines[($UiStart + 1)..($UiEnd - 1)])
  }
  $After = @()
  if ($UiEnd -le ($OriginalLines.Count - 1)) {
    $After = @($OriginalLines[$UiEnd..($OriginalLines.Count - 1)])
  }

  Write-Utf8NoBomLines -Path $ConfigPath -Lines @($Before + $Body + $CssLine + $JsLine + $After)
}

$ResolvedAgentRoot = (Resolve-Path -LiteralPath $AgentRoot).Path
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DropInPublic = Join-Path $PackageRoot "drop_in_public"

if (-not (Test-Path -LiteralPath $DropInPublic -PathType Container)) {
  throw "drop_in_public folder not found next to this script. Run this script from the extracted UI package folder."
}

$RequiredFiles = @(
  "apcot-ui.js",
  "custom.css",
  "title-bar.js",
  "theme-toggle.js",
  "theme.json",
  "app-title.svg"
)

Write-Step "Copying visual UI assets only"
$PublicTarget = Join-Path $ResolvedAgentRoot "public"
New-Item -ItemType Directory -Force -Path $PublicTarget | Out-Null

foreach ($file in $RequiredFiles) {
  $source = Join-Path $DropInPublic $file
  if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw "Missing UI asset: $source"
  }
  Copy-Item -LiteralPath $source -Destination (Join-Path $PublicTarget $file) -Force
  Write-Good "Installed public\$file"
}

Write-Step "Patching Chainlit config for visual assets"
$ConfigPath = Join-Path $ResolvedAgentRoot ".chainlit\config.toml"
$BackupPath = Join-Path $ResolvedAgentRoot ".chainlit\config.toml.visual_ui_backup"
if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
  Copy-Item -LiteralPath $ConfigPath -Destination $BackupPath -Force
}
Set-ChainlitUiAssetConfig -ConfigPath $ConfigPath
Write-Good "Configured custom_css and custom_js"

Write-Step "Verification"
foreach ($file in $RequiredFiles) {
  if (-not (Test-Path -LiteralPath (Join-Path $PublicTarget $file) -PathType Leaf)) {
    throw "Verification failed: public\$file was not found"
  }
}

$ConfigText = Get-Content -Raw -LiteralPath $ConfigPath
if ($ConfigText -notmatch 'custom_css\s*=\s*"/public/custom\.css"') {
  throw "Verification failed: custom_css was not configured"
}
if ($ConfigText -notmatch 'custom_js\s*=\s*"/public/apcot-ui\.js"') {
  throw "Verification failed: custom_js was not configured"
}

Write-Good "Visual UI is enabled without touching chainlit.md, Python, DB, prompt, LLM, or LangGraph files."
Write-Host ""
Write-Host "Now fully stop Chainlit, restart from the agent_api folder, then press Ctrl+F5 in the browser:" -ForegroundColor White
Write-Host "  chainlit run chainlit_app.py --port 8011 -w" -ForegroundColor White
