// APCOT Review Search Engine UI enhancement for Chainlit.
// Drop this file into: agent_api/public/title-bar.js
// It only modifies the browser presentation layer. It does not change the agent, SQL tool, or LLM flow.

(function () {
  const APP_TITLE = "Apcot Review Search Engine";
  const SUBTITLE = "American Express review intelligence hub";
  const READY_TEXT = "Live index connected";

  const QUICK_PROMPTS = [
    "Planning coverage",
    "Never-tested high risk",
    "Repeatable reviews",
    "Findings and remediation",
    "Market drill-down",
    "Generate test script"
  ];

  const SAMPLE_QUERY = "Show review planning coverage, high-risk gaps, repeatable reviews, and remediation status for India.";

  function setDocumentTitle() {
    if (document.title !== APP_TITLE) {
      document.title = APP_TITLE;
    }
  }

  function injectProductPanel() {
    if (document.querySelector(".apcot-product-panel")) return;

    document.body.classList.add("apcot-review-ui");

    const panel = document.createElement("aside");
    panel.className = "apcot-product-panel";
    panel.innerHTML = `
      <div class="apcot-brand-row">
        <div class="apcot-brand">
          <div class="apcot-mark">A</div>
          <div>
            <strong>Apcot Review Search Engine</strong>
            <span>American Express review intelligence hub</span>
          </div>
        </div>
        <span class="apcot-security-pill">Secure - Fast - Searchable</span>
      </div>

      <div class="apcot-eyebrow"><span class="apcot-dot"></span>Planning -> Scoping -> Fieldwork -> Testing -> Report -> Archer</div>

      <h1 class="apcot-hero-title">Turn fragmented <em>review data</em> into planning decisions.</h1>
      <p class="apcot-hero-copy">
        A guided APCOT search and analytics front door that helps ICT users move from many
        files and manual lookups to clear planning outputs: review coverage, repeatable reviews,
        high-risk mandates, test script inputs, findings, and remediation status.
      </p>

      <div class="apcot-flow-card">
        <div class="apcot-flow-title">How the engine works</div>
        <div class="apcot-flow-steps">
          <span>Excel sources</span>
          <span>File processor</span>
          <span>Planning database</span>
          <span>AI search</span>
        </div>
      </div>

      <div class="apcot-metrics">
        <div class="apcot-metric">
          <span>Source coverage</span>
          <strong>12+</strong>
          <small>Reports, LRR, CRA, PRSA/RCSA, RAU, issues</small>
        </div>
        <div class="apcot-metric">
          <span>Planning lens</span>
          <strong>4</strong>
          <small>Coverage, repeat, high-risk, remediation</small>
        </div>
        <div class="apcot-metric">
          <span>Output style</span>
          <strong>Audit</strong>
          <small>Tables, evidence, and tool steps visible</small>
        </div>
      </div>

      <div class="apcot-usecase-grid">
        <button type="button" class="apcot-usecase" data-apcot-prompt="Planning coverage">
          <strong>ICT planning coverage</strong>
          <span>Identify what is already covered by market, country, LOB, risk type, and area of law.</span>
        </button>
        <button type="button" class="apcot-usecase" data-apcot-prompt="Never-tested high risk">
          <strong>Never-tested high-risk mandates</strong>
          <span>Find high/medium/low IRR obligations and flag significant regulatory impact items.</span>
        </button>
        <button type="button" class="apcot-usecase" data-apcot-prompt="Repeatable reviews">
          <strong>Repeatable reviews</strong>
          <span>Use last 3-5 years of plans to identify repeat candidates for the next ICT plan.</span>
        </button>
        <button type="button" class="apcot-usecase" data-apcot-prompt="Findings and remediation">
          <strong>Findings and remediation</strong>
          <span>Summarize top findings, issues, observations, delays, owners, and closure status.</span>
        </button>
      </div>

      <div class="apcot-guide">
        <div class="apcot-guide-title">Use it in three steps</div>
        <div class="apcot-guide-row">
          <b>1</b>
          <span>Choose a planning question: coverage, repeat, high-risk, remediation, market, LOB, or AOL.</span>
        </div>
        <div class="apcot-guide-row">
          <b>2</b>
          <span>Add filters such as country, market region, legal entity, LOB, risk type, status, or review year.</span>
        </div>
        <div class="apcot-guide-row">
          <b>3</b>
          <span>Use the answer table to update the ICT plan, build scope, create scripts, or review remediation.</span>
        </div>
      </div>

      <div class="apcot-bottom-note">
        <div>
          <strong>What to expect back</strong>
          <span>Executive summary, ranked findings, review list, market drill-down, evidence tables, and transparent SQL/tool steps.</span>
        </div>
        <span class="apcot-mini-pill">Apcot ICT Review Search Engine</span>
      </div>
    `;

    document.body.insertBefore(panel, document.body.firstChild);
  }

  function decorateHeader() {
    const header = document.querySelector("header");
    if (!header || header.querySelector(".apcot-header-card")) return;

    const card = document.createElement("div");
    card.className = "apcot-header-card";
    card.innerHTML = `
      <div class="apcot-header-title">
        <div class="apcot-ai-badge">AI</div>
        <div>
          <strong>Review Assistant</strong>
          <span>Ready to search American Express reviews</span>
        </div>
      </div>
      <span class="apcot-live-pill"><span class="apcot-dot live"></span>${READY_TEXT}</span>
    `;

    header.prepend(card);
  }

  function createPromptStrip() {
    if (document.querySelector(".apcot-prompt-strip")) return;

    const main =
      document.querySelector("main") ||
      document.querySelector("[data-testid='main']") ||
      document.querySelector("#root");

    if (!main) return;

    const strip = document.createElement("section");
    strip.className = "apcot-prompt-strip";
    strip.innerHTML = `
      <small>Choose a planning outcome or ask by review ID, market, country, LOB, risk, status, AOL, or keyword <span style="float:right">Powered by APCOT</span></small>
      <div class="apcot-search-shell">
        <span class="apcot-search-icon">Search</span>
        <span>Ask "Show never-tested high-risk mandates for India and generate planning recommendations"</span>
      </div>
      <div class="apcot-chip-row">
        ${QUICK_PROMPTS.map((prompt) => `<button type="button" data-apcot-prompt="${prompt}">${prompt}</button>`).join("")}
      </div>
    `;

    const header = document.querySelector("header");
    if (header && header.parentElement === main) {
      header.insertAdjacentElement("afterend", strip);
    } else {
      main.prepend(strip);
    }
  }

  function setComposerValue(value) {
    const textInput =
      document.querySelector("textarea") ||
      document.querySelector("input[placeholder]") ||
      document.querySelector("[contenteditable='true']");

    if (!textInput) return false;

    textInput.focus();

    if ("value" in textInput) {
      textInput.value = value;
      textInput.dispatchEvent(new Event("input", { bubbles: true }));
      textInput.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      textInput.textContent = value;
      textInput.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    }

    return true;
  }

  function bindPromptStrip() {
    document.querySelectorAll("[data-apcot-prompt]").forEach((button) => {
      if (button.dataset.bound === "true") return;
      button.dataset.bound = "true";
      button.addEventListener("click", () => {
        const label = button.dataset.apcotPrompt || "";
        const questionMap = {
          "Planning coverage": SAMPLE_QUERY,
          "Never-tested high risk": "Show never-tested high-risk mandates and requirements by market, country, risk type, and primary area of law. Highlight items that should be added to the ICT review plan.",
          "Repeatable reviews": "Using the last 3 to 5 years of ICT review plans, identify reviews due for repetition this year by market, business unit, legal entity, risk type, LOB, and area of law.",
          "Findings and remediation": "List the top findings, issues, observations, and remediation status by market, country, risk type, LOB, and primary area of law. Identify delayed plans and delay reasons.",
          "Market drill-down": "Drill down ICT review planning outcomes by market region, country, legal entity, LOB, risk type, status, testing team, and primary area of law.",
          "Generate test script": "For the high-risk requirements added to the ICT review plan, draft test script topics and evidence requests based on prior reviews, findings, and requirement mappings."
        };
        setComposerValue(questionMap[label] || label);
      });
    });
  }

  function updateVisibleTitles() {
    const candidates = [
      "header h1",
      "header h2",
      "[data-testid='header'] h1",
      "[data-testid='header'] h2"
    ];

    candidates.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        const text = (node.textContent || "").trim().toLowerCase();
        if (!text || text === "assistant" || text.includes("chainlit") || text.includes("apcot review search")) {
          node.textContent = APP_TITLE;
        }
      });
    });
  }

  function apply() {
    setDocumentTitle();
    injectProductPanel();
    decorateHeader();
    createPromptStrip();
    bindPromptStrip();
    updateVisibleTitles();
  }

  function start() {
    apply();
    const observer = new MutationObserver(() => apply());
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
