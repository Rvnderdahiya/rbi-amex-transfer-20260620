# APCOT ICT UI Copy/Paste Runbook

Use this package when you have the real Amex project folder, usually named `agent_api`, on the target machine.

## Copy

Copy the full extracted package folder to the Amex machine. Keep these items together:

```text
install_apcot_review_ui.ps1
drop_in_public\
drop_in_root\
drop_in_notes\
```

## Install

Open PowerShell from the package folder and run:

```powershell
.\install_apcot_review_ui.ps1 -AgentRoot "C:\path\to\agent_api" -ReplaceChainlitReadme
```

If PowerShell blocks script execution, run this from the same folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\install_apcot_review_ui.ps1 -AgentRoot "C:\path\to\agent_api" -ReplaceChainlitReadme
```

If this package is already extracted directly inside `agent_api`, run:

```powershell
cd "C:\path\to\agent_api"
powershell -ExecutionPolicy Bypass -File .\install_apcot_review_ui.ps1 -AgentRoot "." -ReplaceChainlitReadme
```

If the package is inside a subfolder under `agent_api`, run:

```powershell
cd "C:\path\to\agent_api\ict_poc_ui_ready_to_apply"
powershell -ExecutionPolicy Bypass -File .\install_apcot_review_ui.ps1 -AgentRoot ".." -ReplaceChainlitReadme
```

## Run The App

From the real `agent_api` folder:

```powershell
chainlit run chainlit_app.py --port 8011 -w
```

Open:

```text
http://localhost:8011
```

Hard refresh the browser with `Ctrl + F5`.

## What Changes

Only UI assets are installed:

```text
agent_api/public/apcot-ui.js
agent_api/public/custom.css
agent_api/public/title-bar.js
agent_api/public/theme-toggle.js
agent_api/public/theme.json
agent_api/public/app-title.svg
agent_api/chainlit.md
```

The installer creates a timestamped backup folder before copying files.

It also activates the UI in:

```text
agent_api\.chainlit\config.toml
```

by setting:

```toml
custom_css = "/public/custom.css"
custom_js = "/public/apcot-ui.js"
```

## What Does Not Change

No Python, LangGraph, LangChain, SQL tool, database, prompt, LLM endpoint, or environment configuration is changed.

## If The New UI Does Not Appear

Check `agent_api\.chainlit\config.toml`. The UI section should reference the custom assets. Chainlit version syntax can vary, but the target should be equivalent to:

```toml
custom_css = "/public/custom.css"
custom_js = "/public/apcot-ui.js"
```

Then restart Chainlit and press `Ctrl + F5`.
