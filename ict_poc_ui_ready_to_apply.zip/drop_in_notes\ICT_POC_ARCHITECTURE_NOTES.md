# ICT POC Reverse-Engineered Architecture Notes

Source available in this local folder: screenshot captures only. No live Python/HTML/JS source files were present in `C:\Users\QSS\Documents\Ravender\amex\ICT_POC` at the time of review.

## Project Shape Seen In Screenshots

```text
agent_api/
  .chainlit/
    translations/
    config.toml
  .files/
  app/
    __init__.py
    config.py
    main.py
    schemas.py
    agent/
      core.py
      tools.py
      prompt.py
  public/
    app-title.svg
    custom.css
    theme-toggle.js
    theme.json
    title-bar.js
  ui/
  .env
  chainlit_app.py
  chainlit.md
  README.md
  requirements.txt
  response.md
```

## Runtime Dependencies

Observed in `requirements.txt`:

```text
fastapi>=0.116.0
uvicorn[standard]>=0.35.0
python-dotenv>=1.1.0
langchain-core>=0.3.0
langgraph>=0.4.0
pydantic>=2.0.0
chainlit>=2.0.0
```

## Backend Flow

- `app/main.py` exposes a FastAPI service called `APCOT SQL Agent API`.
- Routes observed:
  - `GET /health`
  - `POST /ask`
- `POST /ask` accepts `AskRequest` and returns `AskResponse`.
- It calls `run_agent(...)` from `app.agent.core`.
- Runtime config comes from `app.config`.

## Chainlit UI Flow

- `chainlit_app.py` is the primary user-facing UI.
- It imports `run_agent_stream` from `app.agent.core`.
- It streams LangGraph events into Chainlit.
- It groups intermediate events into an expandable step:
  - tool calls
  - SQL queries
  - tool results
  - reasoning/thinking
  - node debug events
- It renders final output using `_render_response(...)`.
- It supports starters such as:
  - Findings for a review
  - Reviews in a country
  - High-risk ratings
  - Requirement count
- It sends a welcome message with a `Continue to Review` action.

## Agent / LLM Shape

README indicates:

- ReAct-style agent loop with LangGraph.
- SQL tool named `query_sql`.
- Database appears to be `apcot_reviews.db`.
- Output contract includes:
  - `output_text`
  - parsed `output_json`
- Review ID normalization guidance exists in system prompt, for example handling formats like `Review-XXXXXX`.
- Redaction support exists around generated flow.
- The enterprise LLM configuration is loaded through internal config/environment settings rather than public API wiring.

## Data Domains Covered

From `chainlit.md` and response examples, the app searches APCOT compliance review records including:

- Reviews
- Requirements
- Findings
- Observations
- Known issues
- Mandates
- Processes
- Risk ratings

Example questions:

- What are the findings for review 1143?
- Show all reviews for Canada.
- Which reviews have high residual risk?
- How many requirements does review 1244 have?
- Show known issues for a specific review.

## UI Customization Surface

The safest UI layer is `agent_api/public/`.

Observed files:

- `custom.css`: Chainlit visual overrides.
- `title-bar.js`: title/header customization.
- `theme-toggle.js`: light/dark theme handling.
- `theme.json`: Chainlit theme variables and Amex font import.
- `app-title.svg`: title icon.

Recommended change strategy:

1. Replace only public UI assets first.
2. Do not touch `app/agent/core.py`, `tools.py`, `prompt.py`, or database wiring.
3. Validate the app still answers the same starter prompts.
4. Only after UI is stable, adjust `chainlit_app.py` welcome text/starters if needed.

## Delivered UI Patch

The drop-in patch was created at:

```text
C:\Users\QSS\Documents\Ravender\amex\ICT_POC\drop_in_public\
```

Files:

- `apcot-ui.js`
- `custom.css`
- `title-bar.js`
- `theme-toggle.js`
- `theme.json`
- `app-title.svg`
- `README_APPLY_UI.md`

Installer:

- `C:\Users\QSS\Documents\Ravender\amex\ICT_POC\install_apcot_review_ui.ps1`
- `C:\Users\QSS\Documents\Ravender\amex\ICT_POC\README_COPY_PASTE.md`
- `C:\Users\QSS\Documents\Ravender\amex\ICT_POC\ict_poc_ui_ready_to_apply.zip`

The installer validates the package, detects the `agent_api` project root, backs up existing UI assets, installs the public UI files, optionally replaces `chainlit.md`, and leaves the Python/LLM/LangGraph/database layer unchanged.

The UI patch is designed to match the expected screenshot:

- left premium product narrative panel
- right review assistant chat panel
- live index connected indicator
- search prompt strip
- quick query chips
- polished answer/message cards
- enterprise Amex-inspired blue and white palette
- dark mode support
