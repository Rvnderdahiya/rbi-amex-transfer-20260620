# APCOT Review Search UI Drop-in

Copy these files into the real project folder on the American Express machine:

```text
agent_api/public/apcot-ui.js
agent_api/public/custom.css
agent_api/public/title-bar.js
agent_api/public/theme-toggle.js
agent_api/public/theme.json
agent_api/public/app-title.svg
```

The easiest route is to keep this whole package together and run:

```powershell
.\install_apcot_review_ui.ps1 -AgentRoot "C:\path\to\agent_api" -ReplaceChainlitReadme
```

## What This Changes

- Adds a premium two-pane landing experience like the expected UI screenshot.
- Adds the left product panel: product name, value proposition, metrics, and capability cards.
- Upgrades the Chainlit header into a "Review Assistant" header with live index indicator.
- Adds quick query chips for planning coverage, never-tested high-risk mandates, repeatable reviews, findings/remediation, market drill-down, and test script generation.
- Styles Chainlit messages, tables, tool steps, composer, cards, and dark mode.

## What This Does Not Change

- No change to `app/agent/core.py`.
- No change to `app/agent/tools.py`.
- No change to `app/agent/prompt.py`.
- No change to `app/main.py`.
- No change to the LangGraph/LangChain/LLM connection.
- No change to the SQLite database or SQL tool.

## If Custom JS Is Not Loading

Check `.chainlit/config.toml` and make sure custom assets are referenced. The exact Chainlit config syntax can differ by version, but most Chainlit 2.x builds support a single CSS and JS reference similar to:

```text
custom_css = "/public/custom.css"
custom_js = "/public/apcot-ui.js"
```

If the CSS changes appear but the left panel does not, then `custom.css` is loading but `apcot-ui.js` or `title-bar.js` is not. In that case, add/restore the custom JS entry in `.chainlit/config.toml`.

## Run

From the project root:

```bash
chainlit run chainlit_app.py --port 8011 -w
```

Then hard-refresh the browser:

```text
Ctrl + F5
```
