# APCOT Review Search UI Drop-in

Copy these files into the real project folder on the American Express machine:

```text
agent_api/public/apcot-ui.js
agent_api/public/custom.css
agent_api/public/title-bar.js
agent_api/public/theme-toggle.js
agent_api/public/theme.json
agent_api/public/app-title.svg
```

The easiest route is to keep this whole package together and run:

```powershell
.\install_apcot_review_ui.ps1 -AgentRoot "C:\path\to\agent_api" -ReplaceChainlitReadme
```

The installer also updates `.chainlit/config.toml` so Chainlit actually loads the new UI:

```toml
custom_css = "/public/custom.css"
custom_js = "/public/apcot-ui.js"
```

## What This Changes

- Adds a premium two-pane landing experience like the expected UI screenshot.
- Adds the left product panel: product name, value proposition, metrics, and capability cards.
- Upgrades the Chainlit header into a "Review Assistant" header with live index indicator.
- Adds quick query chips for planning coverage, never-tested high-risk mandates, repeatable reviews, findings/remediation, market drill-down, and test script generation.
- Styles Chainlit messages, tables, tool steps, composer, cards, and dark mode.

## What This Does Not Change

- No change to `app/agent/core.py`.
- No change to `app/agent/tools.py`.
- No change to `app/agent/prompt.py`.
- No change to `app/main.py`.
- No change to the LangGraph/LangChain/LLM connection.
- No change to the SQLite database or SQL tool.

## If Custom JS Is Not Loading

Check `.chainlit/config.toml` and make sure custom assets are referenced. The exact Chainlit config syntax can differ by version, but most Chainlit 2.x builds support a single CSS and JS reference similar to:

```text
custom_css = "/public/custom.css"
custom_js = "/public/apcot-ui.js"
```

If the page still looks like standard Chainlit, then `custom.css` and `apcot-ui.js` are not being loaded. Re-run the installer after stopping Chainlit, restart the server, and hard refresh with `Ctrl + F5`.

## Run

From the project root:

```bash
chainlit run chainlit_app.py --port 8011 -w
```

Then hard-refresh the browser:

```text
Ctrl + F5
```
