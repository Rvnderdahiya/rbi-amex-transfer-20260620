// Light/dark theme helper for the APCOT Chainlit UI.
// Drop this file into: agent_api/public/theme-toggle.js

(function () {
  const STORAGE_KEYS = ["theme", "color-theme", "chainlit-theme"];

  function getStoredTheme() {
    for (const key of STORAGE_KEYS) {
      try {
        const value = localStorage.getItem(key);
        if (value === "light" || value === "dark") return value;
      } catch (_) {
        // Ignore storage restrictions.
      }
    }
    return "light";
  }

  function setTheme(mode) {
    const root = document.documentElement;
    const body = document.body;

    root.classList.remove("light", "dark");
    root.classList.add(mode);
    root.setAttribute("data-theme", mode);

    if (body) {
      body.classList.remove("light", "dark");
      body.classList.add(mode);
      body.setAttribute("data-theme", mode);
    }

    STORAGE_KEYS.forEach((key) => {
      try {
        localStorage.setItem(key, mode);
      } catch (_) {
        // Ignore storage restrictions.
      }
    });
  }

  function ensureThemeControl() {
    if (document.querySelector("[data-apcot-theme-toggle]")) return;

    const target =
      document.querySelector(".apcot-header-card") ||
      document.querySelector("header") ||
      document.body;

    const button = document.createElement("button");
    button.type = "button";
    button.setAttribute("data-apcot-theme-toggle", "true");
    button.textContent = getStoredTheme() === "dark" ? "Light" : "Dark";
    button.style.cssText = [
      "min-height:34px",
      "border:1px solid #d8e3f2",
      "border-radius:999px",
      "background:#fff",
      "color:#006fcf",
      "font-weight:800",
      "padding:0 12px",
      "cursor:pointer"
    ].join(";");

    button.addEventListener("click", () => {
      const next = getStoredTheme() === "dark" ? "light" : "dark";
      setTheme(next);
      button.textContent = next === "dark" ? "Light" : "Dark";
    });

    target.appendChild(button);
  }

  function apply() {
    setTheme(getStoredTheme());
    ensureThemeControl();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", apply);
  } else {
    apply();
  }

  new MutationObserver(ensureThemeControl).observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();
