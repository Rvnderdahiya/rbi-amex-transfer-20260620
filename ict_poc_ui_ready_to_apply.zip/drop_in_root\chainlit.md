# Apcot Review Search Engine

Welcome to the APCOT Review Search Engine.

Use this assistant to find review details, status, requirements, findings, known issues, risk ratings, mandates, processes, owners, timelines, remediation status, and related evidence from APCOT compliance review data.

The assistant is designed to help across the ICT lifecycle:

```text
Planning -> Scoping -> Kick-Off / Fieldwork -> Testing -> First Draft -> Final Report -> Archer Updates
```

## What You Can Ask

Try natural-language questions such as:

1. What are the findings for review 1143?
2. Show all reviews for Canada.
3. Which reviews have high residual risk?
4. How many requirements does review 1244 have?
5. Show known issues for a specific review.
6. Show recent India reviews and summarize recurring themes.
7. Which AML reviews are complete and who owned them?
8. Summarize review status, owner, and next step for the latest ICT review.
9. Show never-tested high-risk mandates for India and recommend what should be added to the ICT plan.
10. Identify repeatable reviews from the last 3-5 years and group them by market, legal entity, risk type, LOB, and area of law.
11. List top findings, issues, observations, remediation status, delayed plans, and delay reasons.
12. Generate test script topics and evidence requests for high-risk requirements added to the ICT plan.

## Planning Outcomes Supported

Use the assistant for four common planning outcomes:

| Outcome | What To Ask |
|---|---|
| ICT planning coverage | "Show planning coverage by market, country, LOB, risk type, status, and primary area of law." |
| Never-tested high-risk mandates | "Find high-risk mandates or requirements that have not been tested and recommend priority items." |
| Repeatable reviews | "Use the last 3-5 years of ICT plans to identify repeatable reviews for this year." |
| Findings and remediation | "Summarize top findings, open issues, delayed remediation plans, and delay reasons." |

## How It Works

1. Ask a question in plain English.
2. The assistant searches the connected APCOT review database.
3. Intermediate SQL/tool steps are shown for transparency.
4. The final answer is returned in a structured, audit-friendly format.

## Data Covered

The assistant is designed around APCOT compliance review records including:

- Reviews
- Requirements
- Findings
- Observations
- Known issues
- Mandates
- Processes
- Risk ratings

## Tips

- Include a review number when possible.
- Mention a country, status, risk type, date range, or area of law to narrow results.
- Add planning filters such as market region, legal entity, LOB, testing team, or area of law.
- Ask one clear question at a time.
- If the answer is too broad, ask a follow-up with tighter filters.

## Output Style

Answers are designed to be concise first, then evidence-backed:

- Executive summary
- Key findings
- Review table or structured details
- Evidence or source context where available
- Suggested follow-up questions
