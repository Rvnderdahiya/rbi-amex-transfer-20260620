param(
  [string]$AgentRoot = "."
)

$ErrorActionPreference = "Stop"

function Write-Utf8NoBomLines {
  param(
    [string]$Path,
    [string[]]$Lines
  )

  $encoding = New-Object System.Text.UTF8Encoding -ArgumentList $false
  [System.IO.File]::WriteAllLines($Path, $Lines, $encoding)
}

function Clean-TomlLine {
  param([string]$Line)

  if ($null -eq $Line) {
    return ""
  }

  return $Line.Replace([string][char]0xFEFF, "").Replace("ï»¿", "").TrimEnd()
}

function Set-ChainlitUiAssetConfig {
  param([string]$ConfigPath)

  $ConfigDir = Split-Path -Parent $ConfigPath
  New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null

  $CssLine = 'custom_css = "/public/custom.css"'
  $JsLine = 'custom_js = "/public/apcot-ui.js"'

  if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    Write-Utf8NoBomLines -Path $ConfigPath -Lines @("[UI]", $CssLine, $JsLine)
    return "created"
  }

  $OriginalLines = @(Get-Content -LiteralPath $ConfigPath | ForEach-Object { Clean-TomlLine -Line $_ })
  $UiStart = -1

  for ($i = 0; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[UI\]\s*$') {
      $UiStart = $i
      break
    }
  }

  if ($UiStart -lt 0) {
    $UpdatedLines = @($OriginalLines + "" + "[UI]" + $CssLine + $JsLine)
    Write-Utf8NoBomLines -Path $ConfigPath -Lines $UpdatedLines
    return "added-ui-section"
  }

  $UiEnd = $OriginalLines.Count
  for ($i = $UiStart + 1; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[[^\]]+\]\s*$') {
      $UiEnd = $i
      break
    }
  }

  $Before = @($OriginalLines[0..$UiStart])

  $Body = @()
  if (($UiStart + 1) -le ($UiEnd - 1)) {
    $Body = @($OriginalLines[($UiStart + 1)..($UiEnd - 1)])
  }

  $FilteredBody = @()
  foreach ($line in $Body) {
    if ($line -match '^\s*#?\s*custom_css\s*=') {
      continue
    }
    if ($line -match '^\s*#?\s*custom_js\s*=') {
      continue
    }
    $FilteredBody += $line
  }

  $After = @()
  if ($UiEnd -le ($OriginalLines.Count - 1)) {
    $After = @($OriginalLines[$UiEnd..($OriginalLines.Count - 1)])
  }

  $UpdatedLines = @($Before + $FilteredBody + $CssLine + $JsLine + $After)
  Write-Utf8NoBomLines -Path $ConfigPath -Lines $UpdatedLines
  return "updated-ui-section"
}

$ResolvedAgentRoot = (Resolve-Path -LiteralPath $AgentRoot).Path
$ConfigPath = Join-Path $ResolvedAgentRoot ".chainlit\config.toml"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupPath = Join-Path $ResolvedAgentRoot ".chainlit\config.toml.backup_$Timestamp"

if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
  Copy-Item -LiteralPath $ConfigPath -Destination $BackupPath -Force
  Write-Host "Backed up config to: $BackupPath" -ForegroundColor Cyan
}

$result = Set-ChainlitUiAssetConfig -ConfigPath $ConfigPath

Write-Host "Repaired .chainlit\config.toml ($result)." -ForegroundColor Green
Write-Host "Now restart Chainlit and hard refresh the browser with Ctrl+F5." -ForegroundColor Green
