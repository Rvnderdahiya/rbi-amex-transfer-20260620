param(
  [string]$AgentRoot = "",
  [switch]$ReplaceChainlitReadme,
  [switch]$SkipConfigPatch
)

$ErrorActionPreference = "Stop"

function Write-Step {
  param([string]$Message)
  Write-Host ""
  Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Good {
  param([string]$Message)
  Write-Host "OK  $Message" -ForegroundColor Green
}

function Write-WarnLine {
  param([string]$Message)
  Write-Host "WARN $Message" -ForegroundColor Yellow
}

function Resolve-AgentRoot {
  param([string]$InputPath)

  $candidates = @()

  if ($InputPath -and $InputPath.Trim().Length -gt 0) {
    $candidates += $InputPath
  }

  $cwd = (Get-Location).Path
  $candidates += $cwd
  $candidates += (Join-Path $cwd "agent_api")
  $parent = Split-Path -Parent $cwd
  if ($parent) {
    $candidates += (Join-Path $parent "agent_api")
  }

  foreach ($candidate in $candidates | Select-Object -Unique) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Container)) {
      continue
    }

    $resolved = (Resolve-Path -LiteralPath $candidate).Path
    $hasChainlit = Test-Path -LiteralPath (Join-Path $resolved "chainlit_app.py")
    $hasConfig = Test-Path -LiteralPath (Join-Path $resolved ".chainlit\config.toml")

    if ($hasChainlit -or $hasConfig) {
      return $resolved
    }
  }

  throw "Could not find agent_api root. Run this from the agent_api folder or pass -AgentRoot 'C:\path\to\agent_api'."
}

function Set-ChainlitUiAssetConfig {
  param([string]$ConfigPath)

  $ConfigDir = Split-Path -Parent $ConfigPath
  New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null

  $CssLine = 'custom_css = "/public/custom.css"'
  $JsLine = 'custom_js = "/public/apcot-ui.js"'

  if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    Set-Content -LiteralPath $ConfigPath -Value @("[UI]", $CssLine, $JsLine) -Encoding UTF8
    return "created"
  }

  $OriginalLines = @(Get-Content -LiteralPath $ConfigPath)
  $UiStart = -1

  for ($i = 0; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[UI\]\s*$') {
      $UiStart = $i
      break
    }
  }

  if ($UiStart -lt 0) {
    $UpdatedLines = @($OriginalLines + "" + "[UI]" + $CssLine + $JsLine)
    Set-Content -LiteralPath $ConfigPath -Value $UpdatedLines -Encoding UTF8
    return "added-ui-section"
  }

  $UiEnd = $OriginalLines.Count
  for ($i = $UiStart + 1; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[[^\]]+\]\s*$') {
      $UiEnd = $i
      break
    }
  }

  $Before = @()
  if ($UiStart -ge 0) {
    $Before = @($OriginalLines[0..$UiStart])
  }

  $Body = @()
  if (($UiStart + 1) -le ($UiEnd - 1)) {
    $Body = @($OriginalLines[($UiStart + 1)..($UiEnd - 1)])
  }

  $FilteredBody = @()
  foreach ($line in $Body) {
    if ($line -match '^\s*#?\s*custom_css\s*=') {
      continue
    }
    if ($line -match '^\s*#?\s*custom_js\s*=') {
      continue
    }
    $FilteredBody += $line
  }

  $After = @()
  if ($UiEnd -le ($OriginalLines.Count - 1)) {
    $After = @($OriginalLines[$UiEnd..($OriginalLines.Count - 1)])
  }

  $UpdatedLines = @($Before + $FilteredBody + $CssLine + $JsLine + $After)
  Set-Content -LiteralPath $ConfigPath -Value $UpdatedLines -Encoding UTF8
  return "updated-ui-section"
}

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DropInPublic = Join-Path $PackageRoot "drop_in_public"
$DropInRoot = Join-Path $PackageRoot "drop_in_root"

Write-Step "Validating package"

if (-not (Test-Path -LiteralPath $DropInPublic -PathType Container)) {
  throw "Missing drop_in_public folder next to this script."
}

$RequiredPublicFiles = @(
  "apcot-ui.js",
  "custom.css",
  "title-bar.js",
  "theme-toggle.js",
  "theme.json",
  "app-title.svg"
)

foreach ($file in $RequiredPublicFiles) {
  $path = Join-Path $DropInPublic $file
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "Missing required UI file: $path"
  }
}

try {
  Get-Content -Raw -LiteralPath (Join-Path $DropInPublic "theme.json") | ConvertFrom-Json | Out-Null
  Write-Good "theme.json is valid JSON"
} catch {
  throw "theme.json is not valid JSON. $($_.Exception.Message)"
}

$ResolvedAgentRoot = Resolve-AgentRoot -InputPath $AgentRoot
$AgentRootItem = Get-Item -LiteralPath $ResolvedAgentRoot
$PublicTarget = Join-Path $ResolvedAgentRoot "public"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupRoot = Join-Path $ResolvedAgentRoot "_apcot_ui_backup_$Timestamp"

Write-Good "Agent root: $ResolvedAgentRoot"

Write-Step "Checking app structure"

if (Test-Path -LiteralPath (Join-Path $ResolvedAgentRoot "chainlit_app.py")) {
  Write-Good "Found chainlit_app.py"
} else {
  Write-WarnLine "chainlit_app.py was not found. Continuing because this may be a packaged deployment."
}

if (Test-Path -LiteralPath (Join-Path $ResolvedAgentRoot ".chainlit\config.toml")) {
  Write-Good "Found .chainlit\config.toml"
} else {
  Write-WarnLine ".chainlit\config.toml was not found. UI assets will still be copied."
}

Write-Step "Creating backup"
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null

if (Test-Path -LiteralPath $PublicTarget -PathType Container) {
  $PublicBackup = Join-Path $BackupRoot "public"
  Copy-Item -LiteralPath $PublicTarget -Destination $PublicBackup -Recurse -Force
  Write-Good "Backed up existing public folder to $PublicBackup"
} else {
  Write-WarnLine "No existing public folder found; a new one will be created."
}

$ChainlitReadmeTarget = Join-Path $ResolvedAgentRoot "chainlit.md"
if (Test-Path -LiteralPath $ChainlitReadmeTarget -PathType Leaf) {
  Copy-Item -LiteralPath $ChainlitReadmeTarget -Destination (Join-Path $BackupRoot "chainlit.md") -Force
  Write-Good "Backed up chainlit.md"
}

$ConfigPath = Join-Path $ResolvedAgentRoot ".chainlit\config.toml"
if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
  $ConfigBackupDir = Join-Path $BackupRoot ".chainlit"
  New-Item -ItemType Directory -Force -Path $ConfigBackupDir | Out-Null
  Copy-Item -LiteralPath $ConfigPath -Destination (Join-Path $ConfigBackupDir "config.toml") -Force
  Write-Good "Backed up .chainlit\config.toml"
}

Write-Step "Installing APCOT Review Search UI files"
New-Item -ItemType Directory -Force -Path $PublicTarget | Out-Null

foreach ($file in $RequiredPublicFiles) {
  Copy-Item -LiteralPath (Join-Path $DropInPublic $file) -Destination (Join-Path $PublicTarget $file) -Force
  Write-Good "Installed public\$file"
}

if ($ReplaceChainlitReadme) {
  $SourceReadme = Join-Path $DropInRoot "chainlit.md"
  if (Test-Path -LiteralPath $SourceReadme -PathType Leaf) {
    Copy-Item -LiteralPath $SourceReadme -Destination $ChainlitReadmeTarget -Force
    Write-Good "Installed chainlit.md welcome content"
  } else {
    Write-WarnLine "ReplaceChainlitReadme was requested, but drop_in_root\chainlit.md is missing."
  }
} else {
  Write-WarnLine "Skipped chainlit.md replacement. Re-run with -ReplaceChainlitReadme if you want the guided welcome text."
}

if ($SkipConfigPatch) {
  Write-WarnLine "Skipped .chainlit\config.toml patch because -SkipConfigPatch was provided."
} else {
  Write-Step "Activating UI assets in Chainlit config"
  $ConfigResult = Set-ChainlitUiAssetConfig -ConfigPath $ConfigPath
  Write-Good ".chainlit\config.toml $ConfigResult with custom_css and custom_js"
}

Write-Step "Post-install check"

if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
  $ConfigText = Get-Content -Raw -LiteralPath $ConfigPath
  $MissingHints = @()

  if ($ConfigText -notmatch "custom\.css") {
    $MissingHints += "public/custom.css"
  }
  if (($ConfigText -notmatch "apcot-ui\.js") -and ($ConfigText -notmatch "title-bar\.js")) {
    $MissingHints += "public/apcot-ui.js"
  }

  if ($MissingHints.Count -gt 0) {
    Write-WarnLine "The Chainlit config may not reference: $($MissingHints -join ', ')"
    Write-WarnLine "If the page opens without the new panel/header, add custom_css = '/public/custom.css' and custom_js = '/public/apcot-ui.js' under the Chainlit UI section."
  } else {
    Write-Good "Chainlit config already references the custom UI assets"
  }
}

Write-Step "Run"
Write-Host "From the agent_api folder, run:" -ForegroundColor White
Write-Host "  chainlit run chainlit_app.py --port 8011 -w" -ForegroundColor White
Write-Host ""
Write-Host "Then open:" -ForegroundColor White
Write-Host "  http://localhost:8011" -ForegroundColor White
Write-Host ""
Write-Good "UI overlay installed. Backend, LangGraph, database, SQL tool, and LLM settings were not changed."
Write-Host "Backup folder: $BackupRoot" -ForegroundColor DarkGray
