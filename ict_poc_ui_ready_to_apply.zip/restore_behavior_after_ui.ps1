param(
  [string]$AgentRoot = ".",
  [string]$BackupFolder = "",
  [switch]$UseLatestBackup,
  [switch]$DisableUiForTest
)

$ErrorActionPreference = "Stop"

function Write-Step {
  param([string]$Message)
  Write-Host ""
  Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Good {
  param([string]$Message)
  Write-Host "OK  $Message" -ForegroundColor Green
}

function Write-WarnLine {
  param([string]$Message)
  Write-Host "WARN $Message" -ForegroundColor Yellow
}

function Write-Utf8NoBomLines {
  param(
    [string]$Path,
    [string[]]$Lines
  )

  $encoding = New-Object System.Text.UTF8Encoding -ArgumentList $false
  [System.IO.File]::WriteAllLines($Path, $Lines, $encoding)
}

function Clean-TomlLine {
  param([string]$Line)

  if ($null -eq $Line) {
    return ""
  }

  return $Line.Replace([string][char]0xFEFF, "").Replace("ï»¿", "").Replace("Ã¯Â»Â¿", "").TrimEnd()
}

function Set-ChainlitUiAssetConfig {
  param([string]$ConfigPath)

  $CssLine = 'custom_css = "/public/custom.css"'
  $JsLine = 'custom_js = "/public/apcot-ui.js"'

  if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    Write-Utf8NoBomLines -Path $ConfigPath -Lines @("[UI]", $CssLine, $JsLine)
    return
  }

  $OriginalLines = @(Get-Content -LiteralPath $ConfigPath | ForEach-Object { Clean-TomlLine -Line $_ })
  $UiStart = -1

  for ($i = 0; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[UI\]\s*$') {
      $UiStart = $i
      break
    }
  }

  if ($UiStart -lt 0) {
    Write-Utf8NoBomLines -Path $ConfigPath -Lines @($OriginalLines + "" + "[UI]" + $CssLine + $JsLine)
    return
  }

  $UiEnd = $OriginalLines.Count
  for ($i = $UiStart + 1; $i -lt $OriginalLines.Count; $i++) {
    if ($OriginalLines[$i] -match '^\s*\[[^\]]+\]\s*$') {
      $UiEnd = $i
      break
    }
  }

  $Before = @($OriginalLines[0..$UiStart])
  $Body = @()
  if (($UiStart + 1) -le ($UiEnd - 1)) {
    $Body = @($OriginalLines[($UiStart + 1)..($UiEnd - 1)])
  }

  $FilteredBody = @()
  foreach ($line in $Body) {
    if ($line -match '^\s*#?\s*custom_css\s*=') {
      continue
    }
    if ($line -match '^\s*#?\s*custom_js\s*=') {
      continue
    }
    $FilteredBody += $line
  }

  $After = @()
  if ($UiEnd -le ($OriginalLines.Count - 1)) {
    $After = @($OriginalLines[$UiEnd..($OriginalLines.Count - 1)])
  }

  Write-Utf8NoBomLines -Path $ConfigPath -Lines @($Before + $FilteredBody + $CssLine + $JsLine + $After)
}

function Remove-ChainlitUiAssetConfig {
  param([string]$ConfigPath)

  if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    return
  }

  $Lines = @(Get-Content -LiteralPath $ConfigPath | ForEach-Object { Clean-TomlLine -Line $_ })
  $Filtered = @()
  foreach ($line in $Lines) {
    if ($line -match '^\s*custom_css\s*=\s*"/public/custom\.css"\s*$') {
      continue
    }
    if ($line -match '^\s*custom_js\s*=\s*"/public/apcot-ui\.js"\s*$') {
      continue
    }
    $Filtered += $line
  }

  Write-Utf8NoBomLines -Path $ConfigPath -Lines $Filtered
}

$ResolvedAgentRoot = (Resolve-Path -LiteralPath $AgentRoot).Path
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$RepairBackupRoot = Join-Path $ResolvedAgentRoot "_apcot_behavior_repair_backup_$Timestamp"
$ConfigPath = Join-Path $ResolvedAgentRoot ".chainlit\config.toml"
$ChainlitMdPath = Join-Path $ResolvedAgentRoot "chainlit.md"

Write-Step "Finding UI backup"
if ($BackupFolder -and $BackupFolder.Trim().Length -gt 0) {
  $BackupCandidate = $BackupFolder
  if (-not [System.IO.Path]::IsPathRooted($BackupCandidate)) {
    $BackupCandidate = Join-Path $ResolvedAgentRoot $BackupCandidate
  }
  if (-not (Test-Path -LiteralPath $BackupCandidate -PathType Container)) {
    throw "BackupFolder was provided but does not exist: $BackupCandidate"
  }
  $LatestBackup = (Resolve-Path -LiteralPath $BackupCandidate).Path
} else {
  $UiBackups = Get-ChildItem -LiteralPath $ResolvedAgentRoot -Directory -Filter "_apcot_ui_backup_*" | Sort-Object LastWriteTime
  if (-not $UiBackups -or $UiBackups.Count -eq 0) {
    throw "No _apcot_ui_backup_* folder found under $ResolvedAgentRoot. I cannot restore the original behavior files automatically."
  }

  if ($UseLatestBackup) {
    $LatestBackup = $UiBackups[-1].FullName
  } else {
    $LatestBackup = $UiBackups[0].FullName
  }
}

if ($BackupFolder -and $BackupFolder.Trim().Length -gt 0) {
  Write-Good "Using requested backup: $LatestBackup"
} elseif ($UseLatestBackup) {
  Write-Good "Using latest backup: $LatestBackup"
} else {
  Write-Good "Using oldest backup: $LatestBackup"
}

Write-Step "Backing up current behavior files"
New-Item -ItemType Directory -Force -Path $RepairBackupRoot | Out-Null
if (Test-Path -LiteralPath $ChainlitMdPath -PathType Leaf) {
  Copy-Item -LiteralPath $ChainlitMdPath -Destination (Join-Path $RepairBackupRoot "chainlit.md.current") -Force
}
if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
  New-Item -ItemType Directory -Force -Path (Join-Path $RepairBackupRoot ".chainlit") | Out-Null
  Copy-Item -LiteralPath $ConfigPath -Destination (Join-Path $RepairBackupRoot ".chainlit\config.toml.current") -Force
}
Write-Good "Current files backed up to $RepairBackupRoot"

Write-Step "Restoring original chainlit.md"
$OriginalChainlitMd = Join-Path $LatestBackup "chainlit.md"
if (Test-Path -LiteralPath $OriginalChainlitMd -PathType Leaf) {
  Copy-Item -LiteralPath $OriginalChainlitMd -Destination $ChainlitMdPath -Force
  Write-Good "Restored original chainlit.md"
} else {
  Write-WarnLine "No chainlit.md found in latest UI backup."
}

Write-Step "Restoring original Chainlit config"
$OriginalConfig = Join-Path $LatestBackup ".chainlit\config.toml"
if (Test-Path -LiteralPath $OriginalConfig -PathType Leaf) {
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $ConfigPath) | Out-Null
  Copy-Item -LiteralPath $OriginalConfig -Destination $ConfigPath -Force
  Write-Good "Restored original .chainlit\config.toml"
} else {
  Write-WarnLine "No .chainlit\config.toml found in latest UI backup. Keeping current config."
}

if ($DisableUiForTest) {
  Write-Step "Disabling UI custom assets for isolation test"
  Remove-ChainlitUiAssetConfig -ConfigPath $ConfigPath
  Write-Good "Removed custom_css/custom_js references for test mode"
} else {
  Write-Step "Re-enabling visual UI only"
  Set-ChainlitUiAssetConfig -ConfigPath $ConfigPath
  Write-Good "Added only custom_css/custom_js references back to config"
}

Write-Step "Done"
Write-Host "Now restart Chainlit:" -ForegroundColor White
Write-Host "  chainlit run chainlit_app.py --port 8011 -w" -ForegroundColor White
Write-Host ""
Write-Host "Then retest the exact query:" -ForegroundColor White
Write-Host "  give me all the mandates for India market" -ForegroundColor White
Write-Host ""
if ($DisableUiForTest) {
  Write-Host "UI is disabled for isolation. If the query works now, config/public UI is implicated." -ForegroundColor Yellow
} else {
  Write-Host "Visual UI remains enabled, but original chainlit.md/config behavior has been restored." -ForegroundColor Green
}
