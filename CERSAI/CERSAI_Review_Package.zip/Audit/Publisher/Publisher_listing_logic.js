//Vue.use(CersaiPlugin);
//Vue.use(VueLoading);
const constantsList = constants.config.globalProperties.$constantsList;

var notification = createApp({
	name:'notification',
	//i18n : i18n,
	components:{
		custom_tb_text_input_download:custom_tb_text_input_download,
		error_popup:error_popup
	},
	data:function()
	{
		return{
			isErrorPopUpVisible:false,
			errorMessage:'',
			tempList :[],
			notificationList : [],
			currentDate:new Date().getTime(),
			notificationEnList:[],
			notificationHiList:[],
			isPinnedAvl:false,
			isNonPinnedAvl:false,
			
			dowloadJson :{
				FileTypeId :'', 
				fileId :'', 
				fileName : ''	
			},
			myLoader:'',
			
			  //Loader Member Var.
			  fullPage: true,
		      canCancel: false,
		      useSlot: false,
		      loader: 'spinner',
		      color: '#047B45',
		      bgColor: '#4b4b4b',
		      height: 64,
		      width: 64,
		       timeout:5000*60,
		}
		
	},
	
	created()
	{		
		
		try
		{
			var enC1 = JSON.parse(englishData).messages;
		
			var hiC1 = JSON.parse(hindiData).messages;
			
			//var enC3 = JSON.parse(notifications_en).notifications;
			//var hiC3 = JSON.parse(notifications_hi).notifications;
			message.en = Object.assign(enC1);
			message.hi = Object.assign(hiC1);
		}
		catch(e)
		{
			//do nothing
		}
		if(sessionStorage.getItem("lang")!= null)
		{
			 setLocale(sessionStorage.getItem("lang"));
		     i18n.global.locale=sessionStorage.getItem("lang");

		}
		else
		{
			sessionStorage.setItem("lang",'en');
			 setLocale('en');
		     i18n.global.locale='en';
		}
		
	},
	updated()
	{
		
		tcs_globalEventHandlarObj.subscribeEvent("localechanged",this.localeUpdated);
		this.prepareNotifications(this.tempList);
	},
	mounted()
	{
		tcs_globalEventHandlarObj.subscribeEvent("localechanged",this.localeUpdated);
		this.getNotifications();
		
		//this.prepareNotifications(this.tempList);
		
		
		//
		/*for(var i=0;i<this.tempList.length;i++)
		 {
			if(this.tempList[i].messageTitle != "GST E-invoice" && this.tempList[i].messageTitle != "Due to COVID scenario CERSAI helpdesk support" && this.tempList[i].expiryTimestamp>this.currentDate)
			{
				if(this.tempList[i].downloadable)
				{
					document.getElementById(this.tempList[i].fileId).innerHTML='<li style="cursor: pointer; text-align: left!important;color: black !important;" class="nav-item text-center">'+this.convertTimestampToDate(this.tempList[i].messageDate)+' - '+this.tempList[i].messageText+'</li>';
				}
			}
		}*/
		
	},
	methods:
	{
		 startLoader()
			{
			       this.myLoader = this.$loading.show({
			        container: this.fullPage ? null : this.$refs.formContainer,
			        canCancel: this.canCancel,
			        onCancel: this.whenCancelled,
			        color: this.color,
			        backgroundColor: this.bgColor,
			        height: this.height,
			        width: this.width,
			        loader: this.loader,
			        opacity: 0.3,
			      }, this.cersaiSlots);

			      //simulate async call
			      
			      /*timer = setTimeout(() => {
			        console.log(loader);
			       this.myLoader && this.myLoader.hide();
			      }, this.timeout);*/
			
			},
		 stopLoader()
			{
				this.myLoader.hide();
			},
			
		downloadRespectiveFile(val1,val2,val3)
		{
		 this.dowloadJson.FileTypeId =  val3.toString();
		 this.dowloadJson.fileId = val1.toString();
		 this.dowloadJson.fileName = val2.toString();
		 console.log(this.dowloadJson);
		 notification.startLoader();
		 tcsFileComm.downloadFile({
	
				formId : 'downloadAnyFilesPreloginHeader', //	  formId of the form in which file is selected 
				actionId:"cersaicontentmanagement_getDownloadableFileAction", //	  actionId of the service //
				contentType : "application/json", //content type	  of data in which format data is present 
				serverCommMode : "sync",
				
				data: 
				{
					l_objJSONObject : notification.dowloadJson											
				},
				callbackForErrorHandling : function()
				{
					
					
					notification.stopLoader();
					//console.log("handler error response here");
				},
				successcallback : function(response) {
				//	console.log(response);
					
					notification.stopLoader();
				},
				errorcallback(errorCode, errorMessage, errorDetails)
				{
					
					//console.log(response);
					notification.stopLoader();
					if(errorDetails == undefined)
					{
						notification.errorMessage = errorMessage;
						notification.isErrorPopUpVisible = true;
						nextTick(()=>{
							
							notification.$refs.errorPopup.$el.querySelector('.card').style.padding="0px 0%"
						})
					}
					else
					{
						notification.errorMessage = JSON.parse(errorDetails).Failure;
						notification.isErrorPopUpVisible = true;
						nextTick(()=>{
							
							notification.$refs.errorPopup.$el.querySelector('.card').style.padding="0px 0%"
						})
						
					}
				}
	
			});

		},
		convertTimestampToDate(timestamp)
		{
			return CersaiPlugin.secondsToDateConverterForDisplay(timestamp);
		},
		useHTMLtags(stringToConvert)
		{
			return  stringToConvert;
		},
		localeUpdated(lang)
		{
			
			setLocale(lang);
		     i18n.global.locale=lang;
		     window.location.reload();
			
		},
		
		prepareNotifications(myList)
		{
			for(var i=0;i<myList.length;i++)
			 {
				if(myList[i].messageTitle != "GST E-invoice" && myList[i].messageTitle != "Due to COVID scenario CERSAI helpdesk support" && myList[i].expiryTimestamp>this.currentDate)
				{
					
					if(myList[i].downloadable)
					{
						document.getElementById(myList[i].id).innerHTML=this.convertTimestampToDate(myList[i].messageDate)+' - '+myList[i].messageText+'<i class="fa fa-download" style="color: #4d5353; cursor:pointer" ></i>';
					}
					else if(!myList[i].downloadable&&this.checkContaineAnchorTag(myList[i].messageText)){
						
						document.getElementById(myList[i].id).innerHTML=this.convertTimestampToDate(myList[i].messageDate)+' - '+myList[i].messageText+' <i class="fa fa-external-link" style="color: #4d5353;">(External Link)</i>';
					}
					else
					{
						document.getElementById(myList[i].id).innerHTML=this.convertTimestampToDate(myList[i].messageDate)+' - '+myList[i].messageText;
					}
				}
			}
		},
		
		checkContaineAnchorTag(text){
			const parser=new DOMParser();
			const doc=parser.parseFromString(text,"text/html");
			return doc.querySelector("a")!==null;
		},
		
		closeErrorPopUp()
		{
			
			this.errorMessage = '';
			this.isErrorPopUpVisible = false;
			nextTick(()=>{
				
				notification.$refs.errorPopup.$el.querySelector('.card').style.padding="0px 0%"
			})

		},
		
		getNotifications()
		{	
			
			
			this.startLoader();
			tcsServeComm.utils("#notification").rest
			({ 
				url: 'cersaicontentmanagement_getNotificationsJsonFileAction',
				type: 'POST',
				data: {
				},
				targetdiv: "notification",
				contentType: "application/json",
				successcallback : function(response) {
					notification.stopLoader();
					console.log(JSON.parse(response).body);
					notification.notificationEnList = JSON.parse(JSON.parse(response).body)[0];
					notification.notificationHiList = JSON.parse(JSON.parse(response).body)[1];
					
					var enC1 = JSON.parse(englishData).messages;
					var enC2 = JSON.parse(notification.notificationEnList);
					
					var hiC1 = JSON.parse(hindiData).messages;
					var hiC2 = JSON.parse(notification.notificationHiList);
					
					message.en = Object.assign(enC1, enC2);
					message.hi = Object.assign(hiC1, hiC2);
					
					notification.notificationList = [];
					if(notification.$t('downloadList')=="hiC2")
		    		{
						notification.notificationList = hiC2;//JSON.parse(notifications_hi).notifications;
					}
		    		else
		    		{
		    			notification.notificationList = enC2;//JSON.parse(notifications_en).notifications;
		    		}
					var myList = notification.notificationList.sort( function ( a, b ){
						if(notification.isPinnedAvl==false && (a.isMessagePinned==true || b.isMessagePinned==true))
							notification.isPinnedAvl=true;
						if(notification.isNonPinnedAvl==false && (a.isMessagePinned==null || b.isMessagePinned==null || a.isMessagePinned==false || b.isMessagePinned==false))
							notification.isNonPinnedAvl=true;
						if(a.isMessagePinned==b.isMessagePinned)
							return new Date(b.creationTimestamp).getTime() - new Date(a.creationTimestamp).getTime();
						else 
							return !a.isMessagePinned && b.isMessagePinned?1:-1;
					});
					
					
					 
					
					notification.tempList = myList;
					notification.tempList=notification.tempList.map((item, index) => Object.assign({}, item, { id: index + 1 }) );
					
					var currentDate = new Date().getTime();
					
					
					
					//$("#ntfn").empty();	
					
					//notification.prepareNotifications(myList);
					
					/*for(var i=0;i<myList.length;i++)
					 {
						if(myList[i].messageTitle != "GST E-invoice" && myList[i].messageTitle != "Due to COVID scenario CERSAI helpdesk support" && myList[i].expiryTimestamp>this.currentDate)
						{
							if(myList[i].downloadable)
							{
								$("#ntfn").append('<li style="\cursor: pointer; text-align: left!important;color: black !important;" class="nav-item text-center"><a v-on:click.prevent="downloadRespectiveFile(notification.tempList[i].fileId,notification.tempList[i].fileName,notification.tempList[i].fileTypeId)" class="nav-link-1">'+CersaiPlugin.secondsToDateConverterForDisplay(myList[i].messageDate)+" - "+ myList[i].messageText +'</a></li>');
							}
							else
							{
							 $("#ntfn").append('<li style="text-align: left!important;color: black !important;" class="nav-item text-center"><a class="nav-link-1">'+CersaiPlugin.secondsToDateConverterForDisplay(myList[i].messageDate)+" - "+ myList[i].messageText +'</a></li>');
							}
						}
					}*/
					
				},
				errorcallback(errorCode, errorMessage, errorDetails)
				{
					//console.log(response);
					notification.stopLoader();
					if(errorDetails == undefined)
					{
						notification.errorMessage = errorMessage;
						notification.isErrorPopUpVisible = true;
						nextTick(()=>{
							notification.$refs.errorPopup.$el.querySelector('.card').style.padding="0px 0%"
						})
					}
					else
					{
						notification.errorMessage = JSON.parse(errorDetails).Failure;
						notification.isErrorPopUpVisible = true;
						nextTick(()=>{
							notification.$refs.errorPopup.$el.querySelector('.card').style.padding="0px 0%"
						})
						
						
					}
				}
			});
			
			
		}
	},
}).use(CersaiPlugin).use(i18n).use(LoadingPlugin).mount('#notification');